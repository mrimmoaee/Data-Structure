#pragma once
#include "Stack_Queue.h"

namespace LibraryManagementSystem {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Data::SqlClient;
	using namespace System::Data::SqlTypes;
	using namespace System::Data::Sql;



	/// <summary>
	/// Summary for Book
	/// </summary>
	public ref class Book : public System::Windows::Forms::Form
	{
	public:
		Form ^frm7;
		Book(void)
		{
			InitializeComponent();
			Fillcomb();
			//
			//TODO: Add the constructor code here
			//
		}
		Book(Form ^frm2)
		{
			frm7 = frm2;
			InitializeComponent();
			Fillcomb();
			Fillcomb2();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Book()
		{
			if (components)
			{
				delete components;
			}
		}


	internal: SQLinkedList s11;
	private: System::Windows::Forms::TabControl^  ggg;
	protected:
	private: System::Windows::Forms::TabPage^  tabPage1;
	private: System::Windows::Forms::TabPage^  tabPage2;
	private: System::Windows::Forms::Button^  btnAdd;



	private: System::Windows::Forms::TextBox^  txtIsbn;
	private: System::Windows::Forms::TextBox^  txtAuthur;
	private: System::Windows::Forms::TextBox^  txtName;




	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label2;

	private: System::Windows::Forms::DataGridView^  Bookdetail;


	private: System::Windows::Forms::Button^  btnDelete;
	private: System::Windows::Forms::Button^  btnBack;
	private: System::Windows::Forms::Button^  btnDisplay;

	private: System::Windows::Forms::Button^  btnSave;

	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::TextBox^  txtQuantity;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  txtSearch;
	private: System::Windows::Forms::Button^  btnSearch;
	private: System::Windows::Forms::Label^  label11;
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label6;

	private: System::Windows::Forms::DataGridView^  Borrowbook;

	private: System::Windows::Forms::Button^  button7;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::Button^  button6;
	private: System::Windows::Forms::ComboBox^  combStatus;
	private: System::Windows::Forms::TextBox^  txtIssueDate;
	private: System::Windows::Forms::TextBox^  txtReturnDate;


	private: System::Windows::Forms::TextBox^  txtBookIsbn;


	private: System::Windows::Forms::TextBox^  txtTPnumber;


	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Button^  btSearch;

	private: System::Windows::Forms::Label^  label12;
	private: System::Windows::Forms::Label^  label13;
	private: System::Windows::Forms::ComboBox^  comStudentname;
	private: System::Windows::Forms::ComboBox^  comStatus;

	private: System::Windows::Forms::Label^  label14;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Book_Name;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Authur_Name;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  ISBN;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Quantity;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Status;
private: System::Windows::Forms::Button^  btnName;
private: System::Windows::Forms::ComboBox^  comBook;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Student_Name;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Tp_Number;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Name_Book;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  ISBN_Book;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Status_Borrow;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Issue_Date;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Return_Date;
private: System::Windows::Forms::Button^  button1;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Book::typeid));
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle2 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			this->ggg = (gcnew System::Windows::Forms::TabControl());
			this->tabPage1 = (gcnew System::Windows::Forms::TabPage());
			this->btnName = (gcnew System::Windows::Forms::Button());
			this->comStatus = (gcnew System::Windows::Forms::ComboBox());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->txtQuantity = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txtSearch = (gcnew System::Windows::Forms::TextBox());
			this->btnSearch = (gcnew System::Windows::Forms::Button());
			this->btnBack = (gcnew System::Windows::Forms::Button());
			this->btnDisplay = (gcnew System::Windows::Forms::Button());
			this->btnSave = (gcnew System::Windows::Forms::Button());
			this->btnDelete = (gcnew System::Windows::Forms::Button());
			this->btnAdd = (gcnew System::Windows::Forms::Button());
			this->txtIsbn = (gcnew System::Windows::Forms::TextBox());
			this->txtAuthur = (gcnew System::Windows::Forms::TextBox());
			this->txtName = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->Bookdetail = (gcnew System::Windows::Forms::DataGridView());
			this->Book_Name = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Authur_Name = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->ISBN = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Quantity = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Status = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->tabPage2 = (gcnew System::Windows::Forms::TabPage());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->comBook = (gcnew System::Windows::Forms::ComboBox());
			this->comStudentname = (gcnew System::Windows::Forms::ComboBox());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->combStatus = (gcnew System::Windows::Forms::ComboBox());
			this->txtIssueDate = (gcnew System::Windows::Forms::TextBox());
			this->txtReturnDate = (gcnew System::Windows::Forms::TextBox());
			this->txtBookIsbn = (gcnew System::Windows::Forms::TextBox());
			this->txtTPnumber = (gcnew System::Windows::Forms::TextBox());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->btSearch = (gcnew System::Windows::Forms::Button());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->Borrowbook = (gcnew System::Windows::Forms::DataGridView());
			this->Student_Name = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Tp_Number = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Name_Book = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->ISBN_Book = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Status_Borrow = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Issue_Date = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Return_Date = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->ggg->SuspendLayout();
			this->tabPage1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Bookdetail))->BeginInit();
			this->tabPage2->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Borrowbook))->BeginInit();
			this->SuspendLayout();
			// 
			// ggg
			// 
			this->ggg->Controls->Add(this->tabPage1);
			this->ggg->Controls->Add(this->tabPage2);
			this->ggg->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ggg->Location = System::Drawing::Point(0, 0);
			this->ggg->Name = L"ggg";
			this->ggg->SelectedIndex = 0;
			this->ggg->Size = System::Drawing::Size(1030, 530);
			this->ggg->TabIndex = 0;
			// 
			// tabPage1
			// 
			this->tabPage1->BackColor = System::Drawing::Color::LightGray;
			this->tabPage1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"tabPage1.BackgroundImage")));
			this->tabPage1->Controls->Add(this->btnName);
			this->tabPage1->Controls->Add(this->comStatus);
			this->tabPage1->Controls->Add(this->label14);
			this->tabPage1->Controls->Add(this->label12);
			this->tabPage1->Controls->Add(this->txtQuantity);
			this->tabPage1->Controls->Add(this->label4);
			this->tabPage1->Controls->Add(this->txtSearch);
			this->tabPage1->Controls->Add(this->btnSearch);
			this->tabPage1->Controls->Add(this->btnBack);
			this->tabPage1->Controls->Add(this->btnDisplay);
			this->tabPage1->Controls->Add(this->btnSave);
			this->tabPage1->Controls->Add(this->btnDelete);
			this->tabPage1->Controls->Add(this->btnAdd);
			this->tabPage1->Controls->Add(this->txtIsbn);
			this->tabPage1->Controls->Add(this->txtAuthur);
			this->tabPage1->Controls->Add(this->txtName);
			this->tabPage1->Controls->Add(this->label3);
			this->tabPage1->Controls->Add(this->label2);
			this->tabPage1->Controls->Add(this->Bookdetail);
			this->tabPage1->Font = (gcnew System::Drawing::Font(L"Times New Roman", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->tabPage1->ForeColor = System::Drawing::Color::Black;
			this->tabPage1->Location = System::Drawing::Point(4, 28);
			this->tabPage1->Name = L"tabPage1";
			this->tabPage1->Padding = System::Windows::Forms::Padding(3);
			this->tabPage1->Size = System::Drawing::Size(1022, 498);
			this->tabPage1->TabIndex = 0;
			this->tabPage1->Text = L"Book Detail";
			// 
			// btnName
			// 
			this->btnName->Location = System::Drawing::Point(26, 60);
			this->btnName->Name = L"btnName";
			this->btnName->Size = System::Drawing::Size(83, 32);
			this->btnName->TabIndex = 35;
			this->btnName->Text = L"Name :";
			this->btnName->UseVisualStyleBackColor = true;
			this->btnName->Click += gcnew System::EventHandler(this, &Book::btnName_Click);
			// 
			// comStatus
			// 
			this->comStatus->FormattingEnabled = true;
			this->comStatus->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"Available", L"Not Available" });
			this->comStatus->Location = System::Drawing::Point(115, 212);
			this->comStatus->Name = L"comStatus";
			this->comStatus->Size = System::Drawing::Size(192, 30);
			this->comStatus->TabIndex = 34;
			this->comStatus->SelectedIndexChanged += gcnew System::EventHandler(this, &Book::comStatus_SelectedIndexChanged);
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->BackColor = System::Drawing::Color::Transparent;
			this->label14->Font = (gcnew System::Drawing::Font(L"Times New Roman", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label14->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label14->Location = System::Drawing::Point(34, 212);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(71, 22);
			this->label14->TabIndex = 33;
			this->label14->Text = L"Status :";
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->BackColor = System::Drawing::Color::Transparent;
			this->label12->Font = (gcnew System::Drawing::Font(L"Times New Roman", 18, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label12->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label12->Location = System::Drawing::Point(98, 17);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(131, 28);
			this->label12->TabIndex = 32;
			this->label12->Text = L"Book Detail";
			// 
			// txtQuantity
			// 
			this->txtQuantity->Location = System::Drawing::Point(115, 177);
			this->txtQuantity->Name = L"txtQuantity";
			this->txtQuantity->Size = System::Drawing::Size(192, 29);
			this->txtQuantity->TabIndex = 18;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->BackColor = System::Drawing::Color::Transparent;
			this->label4->Font = (gcnew System::Drawing::Font(L"Times New Roman", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label4->Location = System::Drawing::Point(14, 176);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(91, 22);
			this->label4->TabIndex = 17;
			this->label4->Text = L"Quantity :";
			// 
			// txtSearch
			// 
			this->txtSearch->Location = System::Drawing::Point(406, 17);
			this->txtSearch->Name = L"txtSearch";
			this->txtSearch->Size = System::Drawing::Size(556, 29);
			this->txtSearch->TabIndex = 16;
			// 
			// btnSearch
			// 
			this->btnSearch->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnSearch.Image")));
			this->btnSearch->Location = System::Drawing::Point(338, 17);
			this->btnSearch->Name = L"btnSearch";
			this->btnSearch->Size = System::Drawing::Size(46, 33);
			this->btnSearch->TabIndex = 15;
			this->btnSearch->UseVisualStyleBackColor = true;
			this->btnSearch->Click += gcnew System::EventHandler(this, &Book::btnSearch_Click);
			// 
			// btnBack
			// 
			this->btnBack->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->btnBack->Location = System::Drawing::Point(924, 452);
			this->btnBack->Name = L"btnBack";
			this->btnBack->Size = System::Drawing::Size(92, 37);
			this->btnBack->TabIndex = 13;
			this->btnBack->Text = L"Back";
			this->btnBack->UseVisualStyleBackColor = true;
			this->btnBack->Click += gcnew System::EventHandler(this, &Book::btnBack_Click);
			// 
			// btnDisplay
			// 
			this->btnDisplay->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnDisplay.Image")));
			this->btnDisplay->Location = System::Drawing::Point(646, 389);
			this->btnDisplay->Name = L"btnDisplay";
			this->btnDisplay->Size = System::Drawing::Size(69, 54);
			this->btnDisplay->TabIndex = 12;
			this->btnDisplay->UseVisualStyleBackColor = true;
			this->btnDisplay->Click += gcnew System::EventHandler(this, &Book::button1_Click_1);
			// 
			// btnSave
			// 
			this->btnSave->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnSave.Image")));
			this->btnSave->Location = System::Drawing::Point(238, 297);
			this->btnSave->Name = L"btnSave";
			this->btnSave->Size = System::Drawing::Size(69, 54);
			this->btnSave->TabIndex = 11;
			this->btnSave->UseVisualStyleBackColor = true;
			this->btnSave->Click += gcnew System::EventHandler(this, &Book::btnSave_Click);
			// 
			// btnDelete
			// 
			this->btnDelete->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnDelete.Image")));
			this->btnDelete->Location = System::Drawing::Point(140, 297);
			this->btnDelete->Name = L"btnDelete";
			this->btnDelete->Size = System::Drawing::Size(69, 54);
			this->btnDelete->TabIndex = 10;
			this->btnDelete->UseVisualStyleBackColor = true;
			this->btnDelete->Click += gcnew System::EventHandler(this, &Book::btnDelete_Click);
			// 
			// btnAdd
			// 
			this->btnAdd->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnAdd.Image")));
			this->btnAdd->Location = System::Drawing::Point(42, 297);
			this->btnAdd->Name = L"btnAdd";
			this->btnAdd->Size = System::Drawing::Size(63, 54);
			this->btnAdd->TabIndex = 9;
			this->btnAdd->UseVisualStyleBackColor = true;
			this->btnAdd->Click += gcnew System::EventHandler(this, &Book::button1_Click);
			// 
			// txtIsbn
			// 
			this->txtIsbn->Location = System::Drawing::Point(115, 139);
			this->txtIsbn->Name = L"txtIsbn";
			this->txtIsbn->Size = System::Drawing::Size(192, 29);
			this->txtIsbn->TabIndex = 6;
			// 
			// txtAuthur
			// 
			this->txtAuthur->Location = System::Drawing::Point(115, 101);
			this->txtAuthur->Name = L"txtAuthur";
			this->txtAuthur->Size = System::Drawing::Size(192, 29);
			this->txtAuthur->TabIndex = 5;
			// 
			// txtName
			// 
			this->txtName->Location = System::Drawing::Point(115, 63);
			this->txtName->Name = L"txtName";
			this->txtName->Size = System::Drawing::Size(192, 29);
			this->txtName->TabIndex = 4;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::Transparent;
			this->label3->Font = (gcnew System::Drawing::Font(L"Times New Roman", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label3->Location = System::Drawing::Point(40, 140);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(65, 22);
			this->label3->TabIndex = 3;
			this->label3->Text = L"ISBN :";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::Transparent;
			this->label2->Font = (gcnew System::Drawing::Font(L"Times New Roman", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label2->Location = System::Drawing::Point(28, 101);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(77, 22);
			this->label2->TabIndex = 2;
			this->label2->Text = L"Authur :";
			// 
			// Bookdetail
			// 
			this->Bookdetail->BackgroundColor = System::Drawing::SystemColors::ActiveBorder;
			this->Bookdetail->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Bookdetail->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(5) {
				this->Book_Name,
					this->Authur_Name, this->ISBN, this->Quantity, this->Status
			});
			dataGridViewCellStyle2->Alignment = System::Windows::Forms::DataGridViewContentAlignment::TopRight;
			dataGridViewCellStyle2->BackColor = System::Drawing::SystemColors::Window;
			dataGridViewCellStyle2->Font = (gcnew System::Drawing::Font(L"Times New Roman", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			dataGridViewCellStyle2->ForeColor = System::Drawing::Color::Black;
			dataGridViewCellStyle2->SelectionBackColor = System::Drawing::SystemColors::Highlight;
			dataGridViewCellStyle2->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle2->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->Bookdetail->DefaultCellStyle = dataGridViewCellStyle2;
			this->Bookdetail->GridColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->Bookdetail->Location = System::Drawing::Point(349, 68);
			this->Bookdetail->Name = L"Bookdetail";
			this->Bookdetail->Size = System::Drawing::Size(656, 293);
			this->Bookdetail->TabIndex = 0;
			// 
			// Book_Name
			// 
			this->Book_Name->HeaderText = L"Book_Name";
			this->Book_Name->Name = L"Book_Name";
			// 
			// Authur_Name
			// 
			this->Authur_Name->HeaderText = L"Authur_Name";
			this->Authur_Name->Name = L"Authur_Name";
			// 
			// ISBN
			// 
			this->ISBN->HeaderText = L"ISBN";
			this->ISBN->Name = L"ISBN";
			// 
			// Quantity
			// 
			this->Quantity->HeaderText = L"Quantity";
			this->Quantity->Name = L"Quantity";
			// 
			// Status
			// 
			this->Status->HeaderText = L"Status";
			this->Status->Name = L"Status";
			// 
			// tabPage2
			// 
			this->tabPage2->BackColor = System::Drawing::Color::LightGray;
			this->tabPage2->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"tabPage2.BackgroundImage")));
			this->tabPage2->Controls->Add(this->button1);
			this->tabPage2->Controls->Add(this->comBook);
			this->tabPage2->Controls->Add(this->comStudentname);
			this->tabPage2->Controls->Add(this->label13);
			this->tabPage2->Controls->Add(this->button7);
			this->tabPage2->Controls->Add(this->button4);
			this->tabPage2->Controls->Add(this->button5);
			this->tabPage2->Controls->Add(this->button6);
			this->tabPage2->Controls->Add(this->combStatus);
			this->tabPage2->Controls->Add(this->txtIssueDate);
			this->tabPage2->Controls->Add(this->txtReturnDate);
			this->tabPage2->Controls->Add(this->txtBookIsbn);
			this->tabPage2->Controls->Add(this->txtTPnumber);
			this->tabPage2->Controls->Add(this->textBox1);
			this->tabPage2->Controls->Add(this->btSearch);
			this->tabPage2->Controls->Add(this->label11);
			this->tabPage2->Controls->Add(this->label10);
			this->tabPage2->Controls->Add(this->label9);
			this->tabPage2->Controls->Add(this->label8);
			this->tabPage2->Controls->Add(this->label7);
			this->tabPage2->Controls->Add(this->label6);
			this->tabPage2->Controls->Add(this->Borrowbook);
			this->tabPage2->Controls->Add(this->button2);
			this->tabPage2->Location = System::Drawing::Point(4, 28);
			this->tabPage2->Name = L"tabPage2";
			this->tabPage2->Padding = System::Windows::Forms::Padding(3);
			this->tabPage2->Size = System::Drawing::Size(1022, 498);
			this->tabPage2->TabIndex = 1;
			this->tabPage2->Text = L"Borrow Book";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(0, 73);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(121, 31);
			this->button1->TabIndex = 39;
			this->button1->Text = L"Student Name :";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Book::button1_Click_2);
			// 
			// comBook
			// 
			this->comBook->FormattingEnabled = true;
			this->comBook->Location = System::Drawing::Point(124, 146);
			this->comBook->Name = L"comBook";
			this->comBook->Size = System::Drawing::Size(176, 27);
			this->comBook->TabIndex = 38;
			this->comBook->SelectedIndexChanged += gcnew System::EventHandler(this, &Book::comBook_SelectedIndexChanged);
			// 
			// comStudentname
			// 
			this->comStudentname->FormattingEnabled = true;
			this->comStudentname->Location = System::Drawing::Point(124, 76);
			this->comStudentname->Name = L"comStudentname";
			this->comStudentname->Size = System::Drawing::Size(176, 27);
			this->comStudentname->TabIndex = 37;
			this->comStudentname->SelectedIndexChanged += gcnew System::EventHandler(this, &Book::comStudentname_SelectedIndexChanged);
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->BackColor = System::Drawing::Color::Transparent;
			this->label13->Font = (gcnew System::Drawing::Font(L"Times New Roman", 18, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label13->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label13->Location = System::Drawing::Point(57, 29);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(189, 28);
			this->label13->TabIndex = 36;
			this->label13->Text = L"Issue Information";
			// 
			// button7
			// 
			this->button7->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button7.Image")));
			this->button7->Location = System::Drawing::Point(666, 371);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(69, 54);
			this->button7->TabIndex = 35;
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &Book::button7_Click);
			// 
			// button4
			// 
			this->button4->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button4.Image")));
			this->button4->Location = System::Drawing::Point(231, 348);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(69, 54);
			this->button4->TabIndex = 34;
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Book::button4_Click);
			// 
			// button5
			// 
			this->button5->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button5.Image")));
			this->button5->Location = System::Drawing::Point(134, 348);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(69, 54);
			this->button5->TabIndex = 33;
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &Book::button5_Click);
			// 
			// button6
			// 
			this->button6->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button6.Image")));
			this->button6->Location = System::Drawing::Point(42, 348);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(63, 54);
			this->button6->TabIndex = 32;
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &Book::button6_Click);
			// 
			// combStatus
			// 
			this->combStatus->FormattingEnabled = true;
			this->combStatus->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"Issued", L"Return" });
			this->combStatus->Location = System::Drawing::Point(125, 219);
			this->combStatus->Name = L"combStatus";
			this->combStatus->Size = System::Drawing::Size(175, 27);
			this->combStatus->TabIndex = 31;
			// 
			// txtIssueDate
			// 
			this->txtIssueDate->Location = System::Drawing::Point(125, 251);
			this->txtIssueDate->Name = L"txtIssueDate";
			this->txtIssueDate->Size = System::Drawing::Size(175, 26);
			this->txtIssueDate->TabIndex = 30;
			// 
			// txtReturnDate
			// 
			this->txtReturnDate->Location = System::Drawing::Point(124, 287);
			this->txtReturnDate->Name = L"txtReturnDate";
			this->txtReturnDate->Size = System::Drawing::Size(176, 26);
			this->txtReturnDate->TabIndex = 29;
			// 
			// txtBookIsbn
			// 
			this->txtBookIsbn->Location = System::Drawing::Point(125, 182);
			this->txtBookIsbn->Name = L"txtBookIsbn";
			this->txtBookIsbn->Size = System::Drawing::Size(175, 26);
			this->txtBookIsbn->TabIndex = 28;
			// 
			// txtTPnumber
			// 
			this->txtTPnumber->Location = System::Drawing::Point(124, 114);
			this->txtTPnumber->Name = L"txtTPnumber";
			this->txtTPnumber->Size = System::Drawing::Size(176, 26);
			this->txtTPnumber->TabIndex = 26;
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(399, 26);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(587, 26);
			this->textBox1->TabIndex = 24;
			// 
			// btSearch
			// 
			this->btSearch->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btSearch.Image")));
			this->btSearch->Location = System::Drawing::Point(338, 22);
			this->btSearch->Name = L"btSearch";
			this->btSearch->Size = System::Drawing::Size(46, 33);
			this->btSearch->TabIndex = 23;
			this->btSearch->UseVisualStyleBackColor = true;
			this->btSearch->Click += gcnew System::EventHandler(this, &Book::btSearch_Click);
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->BackColor = System::Drawing::Color::Transparent;
			this->label11->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label11->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label11->Location = System::Drawing::Point(16, 287);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(102, 19);
			this->label11->TabIndex = 22;
			this->label11->Text = L"Return Date :";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->BackColor = System::Drawing::Color::Transparent;
			this->label10->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label10->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label10->Location = System::Drawing::Point(27, 251);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(91, 19);
			this->label10->TabIndex = 21;
			this->label10->Text = L"Issue Date :";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->BackColor = System::Drawing::Color::Transparent;
			this->label9->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label9->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label9->Location = System::Drawing::Point(58, 219);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(60, 19);
			this->label9->TabIndex = 20;
			this->label9->Text = L"Status :";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->BackColor = System::Drawing::Color::Transparent;
			this->label8->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label8->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label8->Location = System::Drawing::Point(23, 182);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(96, 19);
			this->label8->TabIndex = 19;
			this->label8->Text = L"Book ISBN :";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->BackColor = System::Drawing::Color::Transparent;
			this->label7->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label7->Location = System::Drawing::Point(23, 150);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(98, 19);
			this->label7->TabIndex = 18;
			this->label7->Text = L"Book Name :";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->BackColor = System::Drawing::Color::Transparent;
			this->label6->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label6->Location = System::Drawing::Point(27, 114);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(94, 19);
			this->label6->TabIndex = 17;
			this->label6->Text = L"TP Number :";
			// 
			// Borrowbook
			// 
			this->Borrowbook->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Borrowbook->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(7) {
				this->Student_Name,
					this->Tp_Number, this->Name_Book, this->ISBN_Book, this->Status_Borrow, this->Issue_Date, this->Return_Date
			});
			this->Borrowbook->Location = System::Drawing::Point(338, 72);
			this->Borrowbook->Name = L"Borrowbook";
			this->Borrowbook->Size = System::Drawing::Size(668, 293);
			this->Borrowbook->TabIndex = 15;
			// 
			// Student_Name
			// 
			this->Student_Name->HeaderText = L"Student_Name";
			this->Student_Name->Name = L"Student_Name";
			// 
			// Tp_Number
			// 
			this->Tp_Number->HeaderText = L"Tp_Number";
			this->Tp_Number->Name = L"Tp_Number";
			// 
			// Name_Book
			// 
			this->Name_Book->HeaderText = L"Name_Book";
			this->Name_Book->Name = L"Name_Book";
			// 
			// ISBN_Book
			// 
			this->ISBN_Book->HeaderText = L"ISBN_Book";
			this->ISBN_Book->Name = L"ISBN_Book";
			// 
			// Status_Borrow
			// 
			this->Status_Borrow->HeaderText = L"Status_Borrow";
			this->Status_Borrow->Name = L"Status_Borrow";
			// 
			// Issue_Date
			// 
			this->Issue_Date->HeaderText = L"Issue_Date";
			this->Issue_Date->Name = L"Issue_Date";
			// 
			// Return_Date
			// 
			this->Return_Date->HeaderText = L"Return_Date";
			this->Return_Date->Name = L"Return_Date";
			// 
			// button2
			// 
			this->button2->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->button2->Location = System::Drawing::Point(924, 451);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(92, 29);
			this->button2->TabIndex = 14;
			this->button2->Text = L"Back";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Book::button2_Click);
			// 
			// Book
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::LightGray;
			this->ClientSize = System::Drawing::Size(1040, 529);
			this->Controls->Add(this->ggg);
			this->Name = L"Book";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Book";
			this->ggg->ResumeLayout(false);
			this->tabPage1->ResumeLayout(false);
			this->tabPage1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Bookdetail))->EndInit();
			this->tabPage2->ResumeLayout(false);
			this->tabPage2->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Borrowbook))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
		SQLinkedList s1;

		String^ theprevioustop = s1.getBottom();

		String^ constring = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
		SqlConnection^ conDataBase = gcnew SqlConnection(constring);
		SqlCommand^ cmdDataBase = gcnew SqlCommand("INSERT INTO [dbo].[Book_Detail]( [Book_Name], [Aurthur_Name], [ISBN], [Quantity], [Status]) VALUES ('" + this->txtName->Text + "' ,'" + this->txtAuthur->Text + "' ,'" + this->txtIsbn->Text + "' , '" + this->txtQuantity->Text + "', '" + this->comStatus->Text + "');", conDataBase);
		SqlCommand^ cmd = gcnew SqlCommand("INSERT INTO [dbo].[Book_Detail] WHERE [Book_Name] ='" + theprevioustop + "'", conDataBase);
		//INSERT INTO [dbo].[Company_Detail] WHERE [Company_Name]
		SqlDataReader^ myReader();
		try {
			conDataBase->Open();


			SqlDataReader^ myReader = cmdDataBase->ExecuteReader();
			while (myReader->Read()) {


			}

			MessageBox::Show("New Information Saved");
		}
		catch (Exception^ ex) {
			MessageBox::Show(ex->Message);
		}

		//Text box clear;
		txtName->Text = ("");
		txtAuthur->Text = ("");
		txtIsbn->Text = ("");
		txtQuantity->Text = ("");
		comStatus->Text = ("");
	}


private: System::Void btnSearch_Click(System::Object^  sender, System::EventArgs^  e) {
	Bookdetail->Rows->Clear();

	try
	{
		SqlConnection^ connection = gcnew SqlConnection();
		connection->ConnectionString = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
		connection->Open();

		SqlCommand^ query = gcnew SqlCommand();
		query->Connection = connection;
		String^ book = txtSearch->Text;
		query->CommandText = "SELECT * FROM [dbo].[Book_Detail] WHERE Book_Name='" + book + "'", connection;


		SqlDataReader^ reader = query->ExecuteReader();

		Boolean exist;

		while (reader->Read() == true)
		{
			String^ id = reader->GetString(0);
			if (book == id)

			{
				exist = true;
				Bookdetail->Rows->Add(book, reader->GetString(1), reader->GetString(2), reader->GetString(3), reader->GetString(4));
			}
			else
			{
				exist = false;
			}
		}
		reader->Close();
		if (exist == true)
		{
			return;
		}
		else
		{
			MessageBox::Show("Book name does not exist");
		}
		connection->Close();
	}
	catch (Exception ^ e)
	{
		MessageBox::Show(e->Message);
	}
}

private: System::Void btnDelete_Click(System::Object^  sender, System::EventArgs^  e) {
	SQLinkedList s1;

	for (int i = 0; i < Bookdetail->Rows->Count - 1; i++)
	{
		s1.enqueue(Bookdetail->Rows[i]->Cells["Book_Name"]->Value->ToString());
	}
	String^ thebottomtop = s1.getBottom();
	s1.dequeue();
	Bookdetail->Rows->Clear();

	SqlConnection^ connection = gcnew SqlConnection("Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true");

	try {
		connection->Open();


		SqlCommand^ cmd = gcnew SqlCommand("DELETE FROM [dbo].[Book_Detail] WHERE Book_Name='" + thebottomtop + "'", connection);
		cmd->ExecuteNonQuery();
		MessageBox::Show("Successfully Deleted");

		SqlCommand^ command = gcnew SqlCommand("SELECT * FROM [dbo].[Book_Detail]", connection);

		SqlDataReader^ reader2 = command->ExecuteReader();
		while (reader2->Read())
		{
			Bookdetail->Rows->Add(reader2[0]->ToString(), reader2[1]->ToString(), reader2[2]->ToString(), reader2[3]->ToString(), reader2[4]->ToString());
		}
		reader2->Close();


	}
	catch (SqlException^ e) {
		MessageBox::Show(e->Message);
	}
	finally{
		connection->Close();
	}
}
private: System::Void btnBack_Click(System::Object^  sender, System::EventArgs^  e) {
		this->Hide();
		frm7->Show();
}
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
	this->Hide();
	frm7->Show();
}
private: System::Void button1_Click_1(System::Object^  sender, System::EventArgs^  e) {

	Bookdetail->Rows->Clear();
	SqlConnection^ connection = gcnew SqlConnection("Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true");
	SQLinkedList s1;
	SqlCommand^ command = gcnew SqlCommand("SELECT * FROM [dbo].[Book_Detail]", connection);
	try {
		connection->Open();
		SqlDataReader^ reader = command->ExecuteReader();

		while (reader->Read())
		{
			s1.enqueue(reader["Book_Name"]->ToString());
		}
		reader->Close();

		for (int i = 0; i < s1.getSize(); i++)
		{
			String^ in = s1.inputData()->ToString();
			SqlCommand^ cmd = gcnew SqlCommand("SELECT * FROM [dbo].[Book_Detail] WHERE Book_Name ='" + in + "'", connection);
			SqlDataReader^ reader2 = cmd->ExecuteReader();
			while (reader2->Read())
			{
				Bookdetail->Rows->Add(in, reader2->GetString(1), reader2->GetString(2), reader2->GetString(3), reader2->GetString(4));
			}
			reader2->Close();
		}



	}
	catch (SqlException^ e) {
		MessageBox::Show(e->Message);
	}
	finally{
		connection->Close();
	}




}
private: System::Void button7_Click(System::Object^  sender, System::EventArgs^  e) {
	Borrowbook->Rows->Clear();
	SqlConnection^ connection = gcnew SqlConnection("Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true");
	SQLinkedList s1;
	SqlCommand^ command = gcnew SqlCommand("SELECT * FROM [dbo].[Borrow_Book]", connection);
	try {
		connection->Open();
		SqlDataReader^ reader = command->ExecuteReader();

		while (reader->Read())
		{
			s1.push(reader["Student_Name"]->ToString());
		}
		reader->Close();

		for (int i = 0; i < s1.getSize(); i++)
		{
			String^ in = s1.inputData()->ToString();
			SqlCommand^ cmd = gcnew SqlCommand("SELECT * FROM [dbo].[Borrow_Book] WHERE Student_Name ='" + in + "'", connection);
			SqlDataReader^ reader2 = cmd->ExecuteReader();
			while (reader2->Read())
			{
				Borrowbook->Rows->Add(in, reader2->GetString(1), reader2->GetString(2), reader2->GetString(3), reader2->GetString(4), reader2->GetString(5), reader2->GetString(6));
			}
			reader2->Close();
		}


	}
	catch (SqlException^ e) {
		MessageBox::Show(e->Message);
	}
	finally{
		connection->Close();
	}
}
private: System::Void comStudentname_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
	String^ comboval = comStudentname->Text;

	String^ constring = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
	SqlConnection^ conDataBase = gcnew SqlConnection(constring);
	SqlCommand^ cmdDataBase = gcnew SqlCommand("SELECT * FROM [dbo].[Student_Information] WHERE Student_Name ='" + comboval + "' ;" , conDataBase);
	SqlDataReader^ myReader;
	try {
		conDataBase->Open();
		myReader = cmdDataBase->ExecuteReader();

		if (myReader->Read()) {
			
			String^ TPval = myReader->GetString(1);
			txtTPnumber->Text = TPval;
			

		}
	}

	catch (SqlException^ e) {
		MessageBox::Show(e->Message);
	}
	finally{
		conDataBase->Close();
	}
	


}
void Fillcomb(void) {
	String^ constring = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
	SqlConnection^ conDataBase = gcnew SqlConnection(constring);
	SqlCommand^ cmdDataBase = gcnew SqlCommand("SELECT * FROM [dbo].[Student_Information]", conDataBase);
	SqlDataReader^ myReader;
	try {
		conDataBase->Open();
		myReader = cmdDataBase->ExecuteReader();
		while (myReader->Read()) {
			String^ vName;
			vName = myReader->GetString(0);
			comStudentname->Items->Add(vName);
			
		}
	}

	catch (SqlException^ e) {
		MessageBox::Show(e->Message);
	}
	finally{
		conDataBase->Close();
	}
		 }

private: System::Void btSearch_Click(System::Object^  sender, System::EventArgs^  e) {
	Borrowbook->Rows->Clear();

	try
	{
		SqlConnection^ connection = gcnew SqlConnection();
		connection->ConnectionString = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
		connection->Open();

		SqlCommand^ query = gcnew SqlCommand();
		query->Connection = connection;
		String^ name = txtSearch->Text;
		query->CommandText = "SELECT * FROM [dbo].[Borrow_Book] WHERE Book_Name='" + name + "'", connection;


		SqlDataReader^ reader = query->ExecuteReader();

		Boolean exist;

		while (reader->Read() == true)
		{
			String^ id = reader->GetString(0);
			if (name == id)

			{
				exist = true;
				Borrowbook->Rows->Add(name, reader->GetString(1), reader->GetString(2), reader->GetString(3), reader->GetString(4), reader->GetString(5), reader->GetString(6));
			}
			else
			{
				exist = false;
			}
		}
		reader->Close();
		if (exist == true)
		{
			return;
		}
		else
		{
			MessageBox::Show("Record does not exist");
		}
		connection->Close();
	}
	catch (Exception ^ e)
	{
		MessageBox::Show(e->Message);
	}
}
private: System::Void btnName_Click(System::Object^  sender, System::EventArgs^  e) {
	Bookdetail->Rows->Clear();

	try
	{
		SqlConnection^ connection = gcnew SqlConnection();
		connection->ConnectionString = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
		connection->Open();

		SqlCommand^ query = gcnew SqlCommand();
		query->Connection = connection;
		String^ name = txtName->Text;
		query->CommandText = "SELECT * FROM [dbo].[Book_Detail] WHERE Book_Name ='" + name + "'", connection;

		SqlDataReader^ reader = query->ExecuteReader();

		Boolean exist;

		while (reader->Read() == true)
		{
			String^ id = reader->GetString(0);
			if (name == id)

			{

				exist = true;
			//	txtName->Text = reader->GetString(0);
				txtAuthur->Text = reader->GetString(1);
				txtIsbn->Text = reader->GetString(2);
				txtQuantity->Text = reader->GetString(3);
				//comStatus->Text = reader->GetString(5);

			}
			else
			{
				exist = false;
			}
		}
		reader->Close();
		if (exist == true)
		{
			return;
		}
		else
		{
			MessageBox::Show("Book does not exist in the database");
		}
		connection->Close();
	}
	catch (Exception ^ e)
	{
		MessageBox::Show(e->Message);
	}
}
private: System::Void btnSave_Click(System::Object^  sender, System::EventArgs^  e) {
	try {
		SqlConnection^ connection = gcnew SqlConnection("Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true");
		connection->Open();
		String^ name = txtName->Text;
		String^ Authur = txtAuthur->Text;
		String^ ISBN = txtIsbn->Text;
		String^ Quantity = txtQuantity->Text;
		String^ Status = comStatus->Text;

		SqlCommand^ query = gcnew SqlCommand();
		query->Connection = connection;
		query->CommandText = "UPDATE [dbo].[Book_Detail] SET Aurthur_Name = '" + Authur + "', [ISBN] = '" + ISBN + "', [Quantity] = '" + Quantity + "', [Status] = '" + Status + "' WHERE Book_Name = '" + name + "'", connection;
		SqlDataReader^ reader = query->ExecuteReader();
		MessageBox::Show("Update Successful!");
		connection->Close();
		reader->Close();
	}
	catch (Exception^ e)
	{
		MessageBox::Show(e->Message);
	}

	//Text box clear;
	txtName->Text = ("");
	txtAuthur->Text = ("");
	txtIsbn->Text = ("");
	txtQuantity->Text = ("");
}


 void Fillcomb2(void) {
			 String^ constring = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
			 SqlConnection^ conDataBase = gcnew SqlConnection(constring);
			 SqlCommand^ cmdDataBase = gcnew SqlCommand("SELECT *  FROM [dbo].[Book_Detail]", conDataBase);
			 SqlDataReader^ myReader;
			 try {
				 conDataBase->Open();
				 myReader = cmdDataBase->ExecuteReader();
				 while (myReader->Read()) {
					 String^ vName;
					 vName = myReader->GetString(0);
					 comBook->Items->Add(vName);

				 }
			 }

			 catch (SqlException^ e) {
				 MessageBox::Show(e->Message);
			 }
			 finally{
				 conDataBase->Close();
			 }
		 }
private: System::Void comBook_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
	String^ comboval = comBook->Text;

	String^ constring = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
	SqlConnection^ conDataBase = gcnew SqlConnection(constring);
	SqlCommand^ cmdDataBase = gcnew SqlCommand("SELECT *  FROM [dbo].[Book_Detail] WHERE Book_Name ='" + comboval + "' ;", conDataBase);
	SqlDataReader^ myReader;
	try {
		conDataBase->Open();
		myReader = cmdDataBase->ExecuteReader();

		if (myReader->Read()) {

			String^ Isbn= myReader->GetString(2);
			txtBookIsbn->Text = Isbn;


		}
	}

	catch (SqlException^ e) {
		MessageBox::Show(e->Message);
	}
	finally{
		conDataBase->Close();
	}

}
private: System::Void button6_Click(System::Object^  sender, System::EventArgs^  e) {
	SQLinkedList s1;

	String^ theprevioustop = s1.getBottom();

	String^ constring = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
	SqlConnection^ conDataBase = gcnew SqlConnection(constring);
	SqlCommand^ cmdDataBase = gcnew SqlCommand("INSERT INTO  [dbo].[Borrow_Book] ([Student_Name], [TP_Number], [Book_Name], [ISBN], [Status], [Issue_Date], [Return_Date]) VALUES ('" + this->comStudentname->Text + "' ,'" + this->txtTPnumber->Text + "' ,'" + this->comBook->Text + "' , '" + this->txtBookIsbn->Text + "' , '" + this->combStatus->Text + "' , '" + this->txtIssueDate->Text + "' , '" + this->txtReturnDate->Text + "');", conDataBase);
	SqlCommand^ cmd = gcnew SqlCommand("INSERT INTO [dbo].[Borrow_Book] WHERE [Student_Name] ='" + theprevioustop + "'", conDataBase);
	//INSERT INTO [dbo].[Company_Detail] WHERE [Company_Name]
	SqlDataReader^ myReader();
	try {
		conDataBase->Open();


		SqlDataReader^ myReader = cmdDataBase->ExecuteReader();
		while (myReader->Read()) {


		}

		MessageBox::Show("New Information Saved");
	}
	catch (Exception^ ex) {
		MessageBox::Show(ex->Message);
	}

	//Text box clear;
//	txtName->Text = ("");
	txtTPnumber->Text = ("");
	txtBookIsbn->Text = ("");
	txtIssueDate->Text = ("");
	txtReturnDate->Text = ("");
}
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) {
	SQLinkedList s1;

	for (int i = 0; i < Borrowbook->Rows->Count - 1; i++)
	{
		s1.enqueue(Borrowbook->Rows[i]->Cells["Student_Name"]->Value->ToString());
	}
	String^ thebottomtop = s1.getBottom();
	s1.dequeue();
	Borrowbook->Rows->Clear();

	SqlConnection^ connection = gcnew SqlConnection("Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true");

	try {
		connection->Open();


		SqlCommand^ cmd = gcnew SqlCommand("DELETE FROM [dbo].[Borrow_Book] WHERE Student_Name='" + thebottomtop + "'", connection);
		cmd->ExecuteNonQuery();
		MessageBox::Show("Successfully Deleted");

		SqlCommand^ command = gcnew SqlCommand("SELECT * FROM [dbo].[Borrow_Book]", connection);

		SqlDataReader^ reader2 = command->ExecuteReader();
		while (reader2->Read())
		{
			Bookdetail->Rows->Add(reader2[0]->ToString(), reader2[1]->ToString(), reader2[2]->ToString(), reader2[3]->ToString(), reader2[4]->ToString(), reader2[5]->ToString(), reader2[6]->ToString());
		}
		reader2->Close();


	}
	catch (SqlException^ e) {
		MessageBox::Show(e->Message);
	}
	finally{
		connection->Close();
	}
}
private: System::Void button1_Click_2(System::Object^  sender, System::EventArgs^  e) {
	Borrowbook->Rows->Clear();

	try
	{
		SqlConnection^ connection = gcnew SqlConnection();
		connection->ConnectionString = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
		connection->Open();

		SqlCommand^ query = gcnew SqlCommand();
		query->Connection = connection;
		String^ name = comStudentname->Text;
		query->CommandText = "SELECT * FROM [dbo].[Borrow_Book] WHERE [Student_Name] ='" + name + "'", connection;

		SqlDataReader^ reader = query->ExecuteReader();

		Boolean exist;

		while (reader->Read() == true)
		{
			String^ id = reader->GetString(0);
			if (name == id)

			{

				exist = true;
				txtTPnumber->Text = reader->GetString(1);
				comBook->Text = reader->GetString(2);
				txtBookIsbn->Text = reader->GetString(3);
				combStatus->Text = reader->GetString(4);
				txtIssueDate->Text = reader->GetString(5);
				txtReturnDate->Text = reader->GetString(6);

			}
			else
			{
				exist = false;
			}
		}
		reader->Close();
		if (exist == true)
		{
			return;
		}
		else
		{
			MessageBox::Show("Company Name does not exist in the database");
		}
		connection->Close();
	}
	catch (Exception ^ e)
	{
		MessageBox::Show(e->Message);
	}
}
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
	try {
		SqlConnection^ connection = gcnew SqlConnection("Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true");
		connection->Open();
		String^ name = comStudentname->Text;
		String^ TPnumber = txtTPnumber->Text;
		String^ bookname = comBook->Text;
		String^ Isbn = txtBookIsbn->Text;
		String^ Status = combStatus->Text;
		String^ Issuedate = txtIssueDate->Text;
		String^ Returndate = txtReturnDate->Text;

	

		SqlCommand^ query = gcnew SqlCommand();
		query->Connection = connection;
		query->CommandText = "UPDATE [dbo].[Borrow_Book] SET TP_Number = '" + TPnumber + "', [Book_Name] = '" + bookname + "', [ISBN] = '" + Isbn + "', [Status] = '" + Status + "', [Issue_Date] = '" + Issuedate + "', [Return_Date] = '" + Returndate + "' WHERE Student_Name = '" + name + "'", connection;
		SqlDataReader^ reader = query->ExecuteReader();
		MessageBox::Show("Update Successful!");
		connection->Close();
		reader->Close();
	}
	catch (Exception^ e)
	{
		MessageBox::Show(e->Message);
	}

	//Text box clear;
	//comStudentname->Text = ("");
	txtTPnumber->Text = ("");
	//comBook->Text = ("");
	txtBookIsbn->Text = ("");
	//combStatus->Text = ("");
	txtIssueDate->Text = ("");
	txtReturnDate->Text = ("");
}
private: System::Void comStatus_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
}
};
}
