#pragma once
#include "Stack_Queue.h"

namespace LibraryManagementSystem {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Data::SqlClient;

	/// <summary>
	/// Summary for Stock
	/// </summary>
	public ref class Stock : public System::Windows::Forms::Form
	{
	public:
		Form ^frm9;
		Stock(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}
		Stock(Form ^frm3)
		{
			frm9 = frm3;
			InitializeComponent();
			Fillcomb2();
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Stock()
		{
			if (components)
			{
				delete components;
			}
		}

	internal: SQLinkedList s11;
	private: System::Windows::Forms::DataGridView^  Order_Info;
	protected:

	protected:








	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Button^  btnAdd;
	private: System::Windows::Forms::Button^  btnDelete;
	private: System::Windows::Forms::Button^  btnSave;
	private: System::Windows::Forms::Button^  btnLoad;
	private: System::Windows::Forms::Button^  btnBack;




	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::ComboBox^  combStatus;
	private: System::Windows::Forms::TextBox^  txtBookname;
	private: System::Windows::Forms::TextBox^  txtAuthurname;
	private: System::Windows::Forms::TextBox^  txtOrderdate;



	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::ComboBox^  combCompanyname;

	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtQuantity;
	private: System::Windows::Forms::TextBox^  txtSearch;


	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Order_ID;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Book_Name;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Authur_Name;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Quantity;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Company_name;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Order_Date;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Status;
	private: System::Windows::Forms::TextBox^  txtOrderid;

	private: System::Windows::Forms::Button^  btnOrder;

	protected:





	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Stock::typeid));
			this->Order_Info = (gcnew System::Windows::Forms::DataGridView());
			this->Order_ID = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Book_Name = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Authur_Name = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Quantity = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Company_name = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Order_Date = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Status = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->btnAdd = (gcnew System::Windows::Forms::Button());
			this->btnDelete = (gcnew System::Windows::Forms::Button());
			this->btnSave = (gcnew System::Windows::Forms::Button());
			this->btnLoad = (gcnew System::Windows::Forms::Button());
			this->btnBack = (gcnew System::Windows::Forms::Button());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->combStatus = (gcnew System::Windows::Forms::ComboBox());
			this->txtBookname = (gcnew System::Windows::Forms::TextBox());
			this->txtAuthurname = (gcnew System::Windows::Forms::TextBox());
			this->txtOrderdate = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->combCompanyname = (gcnew System::Windows::Forms::ComboBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtQuantity = (gcnew System::Windows::Forms::TextBox());
			this->txtSearch = (gcnew System::Windows::Forms::TextBox());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->txtOrderid = (gcnew System::Windows::Forms::TextBox());
			this->btnOrder = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Order_Info))->BeginInit();
			this->SuspendLayout();
			// 
			// Order_Info
			// 
			this->Order_Info->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Order_Info->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(7) {
				this->Order_ID,
					this->Book_Name, this->Authur_Name, this->Quantity, this->Company_name, this->Order_Date, this->Status
			});
			this->Order_Info->Location = System::Drawing::Point(349, 75);
			this->Order_Info->Name = L"Order_Info";
			this->Order_Info->Size = System::Drawing::Size(733, 292);
			this->Order_Info->TabIndex = 28;
			// 
			// Order_ID
			// 
			this->Order_ID->HeaderText = L"Order_ID";
			this->Order_ID->Name = L"Order_ID";
			// 
			// Book_Name
			// 
			this->Book_Name->HeaderText = L"Book_Name";
			this->Book_Name->Name = L"Book_Name";
			// 
			// Authur_Name
			// 
			this->Authur_Name->HeaderText = L"Authur_Name";
			this->Authur_Name->Name = L"Authur_Name";
			// 
			// Quantity
			// 
			this->Quantity->HeaderText = L"Quantity";
			this->Quantity->Name = L"Quantity";
			// 
			// Company_name
			// 
			this->Company_name->HeaderText = L"Company_name";
			this->Company_name->Name = L"Company_name";
			// 
			// Order_Date
			// 
			this->Order_Date->HeaderText = L"Order_Date";
			this->Order_Date->Name = L"Order_Date";
			// 
			// Status
			// 
			this->Status->HeaderText = L"Status";
			this->Status->Name = L"Status";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->BackColor = System::Drawing::Color::Transparent;
			this->label5->Font = (gcnew System::Drawing::Font(L"Times New Roman", 24, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::SystemColors::ButtonFace;
			this->label5->Location = System::Drawing::Point(90, 33);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(180, 36);
			this->label5->TabIndex = 31;
			this->label5->Text = L"Order Detail";
			// 
			// btnAdd
			// 
			this->btnAdd->BackColor = System::Drawing::Color::Transparent;
			this->btnAdd->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnAdd.Image")));
			this->btnAdd->Location = System::Drawing::Point(42, 313);
			this->btnAdd->Name = L"btnAdd";
			this->btnAdd->Size = System::Drawing::Size(63, 54);
			this->btnAdd->TabIndex = 32;
			this->btnAdd->UseVisualStyleBackColor = false;
			this->btnAdd->Click += gcnew System::EventHandler(this, &Stock::btnAdd_Click);
			// 
			// btnDelete
			// 
			this->btnDelete->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnDelete.Image")));
			this->btnDelete->Location = System::Drawing::Point(134, 313);
			this->btnDelete->Name = L"btnDelete";
			this->btnDelete->Size = System::Drawing::Size(69, 54);
			this->btnDelete->TabIndex = 33;
			this->btnDelete->UseVisualStyleBackColor = true;
			this->btnDelete->Click += gcnew System::EventHandler(this, &Stock::btnDelete_Click);
			// 
			// btnSave
			// 
			this->btnSave->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnSave.Image")));
			this->btnSave->Location = System::Drawing::Point(231, 313);
			this->btnSave->Name = L"btnSave";
			this->btnSave->Size = System::Drawing::Size(69, 54);
			this->btnSave->TabIndex = 34;
			this->btnSave->UseVisualStyleBackColor = true;
			this->btnSave->Click += gcnew System::EventHandler(this, &Stock::btnSave_Click);
			// 
			// btnLoad
			// 
			this->btnLoad->BackColor = System::Drawing::Color::Transparent;
			this->btnLoad->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnLoad.Image")));
			this->btnLoad->Location = System::Drawing::Point(677, 373);
			this->btnLoad->Name = L"btnLoad";
			this->btnLoad->Size = System::Drawing::Size(69, 54);
			this->btnLoad->TabIndex = 35;
			this->btnLoad->UseVisualStyleBackColor = false;
			this->btnLoad->Click += gcnew System::EventHandler(this, &Stock::btnLoad_Click);
			// 
			// btnBack
			// 
			this->btnBack->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->btnBack->Location = System::Drawing::Point(990, 423);
			this->btnBack->Name = L"btnBack";
			this->btnBack->Size = System::Drawing::Size(92, 29);
			this->btnBack->TabIndex = 15;
			this->btnBack->Text = L"Back";
			this->btnBack->UseVisualStyleBackColor = true;
			this->btnBack->Click += gcnew System::EventHandler(this, &Stock::button2_Click);
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->BackColor = System::Drawing::Color::Transparent;
			this->label7->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label7->Location = System::Drawing::Point(44, 119);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(98, 19);
			this->label7->TabIndex = 38;
			this->label7->Text = L"Book Name :";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->BackColor = System::Drawing::Color::Transparent;
			this->label8->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label8->ForeColor = System::Drawing::SystemColors::ButtonFace;
			this->label8->Location = System::Drawing::Point(33, 148);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(108, 19);
			this->label8->TabIndex = 39;
			this->label8->Text = L"Authur Name :";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->BackColor = System::Drawing::Color::Transparent;
			this->label9->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label9->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label9->Location = System::Drawing::Point(80, 261);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(60, 19);
			this->label9->TabIndex = 40;
			this->label9->Text = L"Status :";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->BackColor = System::Drawing::Color::Transparent;
			this->label10->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label10->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label10->Location = System::Drawing::Point(45, 231);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(95, 19);
			this->label10->TabIndex = 41;
			this->label10->Text = L"Order Date :";
			// 
			// combStatus
			// 
			this->combStatus->FormattingEnabled = true;
			this->combStatus->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"Ordered", L"Delivered" });
			this->combStatus->Location = System::Drawing::Point(146, 262);
			this->combStatus->Name = L"combStatus";
			this->combStatus->Size = System::Drawing::Size(151, 21);
			this->combStatus->TabIndex = 49;
			// 
			// txtBookname
			// 
			this->txtBookname->Location = System::Drawing::Point(149, 120);
			this->txtBookname->Name = L"txtBookname";
			this->txtBookname->Size = System::Drawing::Size(151, 20);
			this->txtBookname->TabIndex = 45;
			// 
			// txtAuthurname
			// 
			this->txtAuthurname->Location = System::Drawing::Point(149, 149);
			this->txtAuthurname->Name = L"txtAuthurname";
			this->txtAuthurname->Size = System::Drawing::Size(151, 20);
			this->txtAuthurname->TabIndex = 46;
			// 
			// txtOrderdate
			// 
			this->txtOrderdate->Location = System::Drawing::Point(146, 232);
			this->txtOrderdate->Name = L"txtOrderdate";
			this->txtOrderdate->Size = System::Drawing::Size(151, 20);
			this->txtOrderdate->TabIndex = 48;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::Transparent;
			this->label1->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label1->Location = System::Drawing::Point(16, 203);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(125, 19);
			this->label1->TabIndex = 50;
			this->label1->Text = L"Company Name :";
			// 
			// combCompanyname
			// 
			this->combCompanyname->FormattingEnabled = true;
			this->combCompanyname->Location = System::Drawing::Point(147, 204);
			this->combCompanyname->Name = L"combCompanyname";
			this->combCompanyname->Size = System::Drawing::Size(151, 21);
			this->combCompanyname->TabIndex = 51;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::Transparent;
			this->label2->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->ForeColor = System::Drawing::SystemColors::ButtonFace;
			this->label2->Location = System::Drawing::Point(64, 177);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(76, 19);
			this->label2->TabIndex = 52;
			this->label2->Text = L"Quantity :";
			// 
			// txtQuantity
			// 
			this->txtQuantity->Location = System::Drawing::Point(149, 178);
			this->txtQuantity->Name = L"txtQuantity";
			this->txtQuantity->Size = System::Drawing::Size(151, 20);
			this->txtQuantity->TabIndex = 53;
			// 
			// txtSearch
			// 
			this->txtSearch->Location = System::Drawing::Point(532, 33);
			this->txtSearch->Name = L"txtSearch";
			this->txtSearch->Size = System::Drawing::Size(418, 20);
			this->txtSearch->TabIndex = 55;
			// 
			// button3
			// 
			this->button3->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button3.Image")));
			this->button3->Location = System::Drawing::Point(480, 26);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(46, 33);
			this->button3->TabIndex = 54;
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Stock::button3_Click);
			// 
			// txtOrderid
			// 
			this->txtOrderid->Location = System::Drawing::Point(149, 94);
			this->txtOrderid->Name = L"txtOrderid";
			this->txtOrderid->Size = System::Drawing::Size(151, 20);
			this->txtOrderid->TabIndex = 56;
			// 
			// btnOrder
			// 
			this->btnOrder->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnOrder->Location = System::Drawing::Point(65, 91);
			this->btnOrder->Name = L"btnOrder";
			this->btnOrder->Size = System::Drawing::Size(75, 23);
			this->btnOrder->TabIndex = 58;
			this->btnOrder->Text = L"Order_ID :";
			this->btnOrder->UseVisualStyleBackColor = true;
			this->btnOrder->Click += gcnew System::EventHandler(this, &Stock::btnOrder_Click);
			// 
			// Stock
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::LightGray;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(1107, 464);
			this->Controls->Add(this->btnOrder);
			this->Controls->Add(this->txtOrderid);
			this->Controls->Add(this->txtSearch);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->txtQuantity);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->combCompanyname);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->combStatus);
			this->Controls->Add(this->txtOrderdate);
			this->Controls->Add(this->txtAuthurname);
			this->Controls->Add(this->txtBookname);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->btnLoad);
			this->Controls->Add(this->btnSave);
			this->Controls->Add(this->btnDelete);
			this->Controls->Add(this->btnAdd);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->Order_Info);
			this->Controls->Add(this->btnBack);
			this->Name = L"Stock";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Stock";
			this->Load += gcnew System::EventHandler(this, &Stock::Stock_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Order_Info))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
		this->Hide();
		frm9->Show();
	}
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
	   this->Hide();
	   frm9->Show();
}
private: System::Void btnLoad_Click(System::Object^  sender, System::EventArgs^  e) {

	Order_Info->Rows->Clear();
	SqlConnection^ connection = gcnew SqlConnection("Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true");

	SQLinkedList s1;
	SqlCommand^ command = gcnew SqlCommand("SELECT * FROM [dbo].[Order_Detail]", connection);

	try {
		connection->Open();
		SqlDataReader^ reader2 = command->ExecuteReader();

		while (reader2->Read())
		{

			Order_Info->Rows->Add(reader2[0]->ToString(), reader2[1]->ToString(), reader2[2]->ToString(), reader2[3]->ToString(), reader2[4]->ToString(), reader2[5]->ToString(), reader2[6]->ToString());

			s1.push(reader2["OrderID"]->ToString());
		}
		reader2->Close();


	}
	catch (SqlException^ e) {
		MessageBox::Show(e->Message);
	}
	finally{
		connection->Close();
	}

}
private: System::Void btnAdd_Click(System::Object^  sender, System::EventArgs^  e) {
    //connection to database
	String^ constring = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
	SqlConnection^ conDataBase = gcnew SqlConnection(constring);
	//Table of database and insert the value inside database
	SqlCommand^ cmdDataBase = gcnew SqlCommand("INSERT INTO [dbo].[Order_Detail]([OrderID],[Book_Name], [Aurthur_Name], [Quantity], [Company_Name], [Order_Date], [Status])VALUES ('" + this->txtOrderid->Text + "' ,'" + this->txtBookname->Text + "' ,'" + this->txtAuthurname->Text + "' , '" + this->txtQuantity->Text + "' , '" + this->combCompanyname->Text + "' , '" + this->txtOrderdate->Text + "' , '" + this->combStatus->Text + "');", conDataBase);

	//Reader
	SqlDataReader^ myReader();
	try {

		//open connection
		conDataBase->Open();


		SqlDataReader^ myReader = cmdDataBase->ExecuteReader();
		while (myReader->Read()) {


		}

		MessageBox::Show("New Order Added");
	}
	catch (Exception^ ex) {
		MessageBox::Show(ex->Message);
	}

   // Textbox clear;
	txtOrderid->Text = ("");
    txtBookname->Text = ("");
	txtAuthurname->Text = ("");
	txtQuantity->Text = ("");
	txtOrderdate->Text = ("");

}
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
	Order_Info->Rows->Clear();

	try
	{
		SqlConnection^ connection = gcnew SqlConnection();
		connection->ConnectionString = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
		connection->Open();

		SqlCommand^ query = gcnew SqlCommand();
		query->Connection = connection;
		String^ OrderID = txtSearch->Text;
		query->CommandText = "SELECT * FROM [dbo].[Order_Detail] WHERE OrderID='" + OrderID + "'", connection;


		SqlDataReader^ reader = query->ExecuteReader();

		Boolean exist;

		while (reader->Read() == true)
		{
			String^ id = reader->GetString(0);
			if (OrderID == id)

			{
				exist = true;
				Order_Info->Rows->Add(OrderID, reader->GetString(1), reader->GetString(2), reader->GetString(3), reader->GetString(4), reader->GetString(5), reader->GetString(6));
			}
			else
			{
				exist = false;
			}
		}
		reader->Close();
		if (exist == true)
		{
			return;
		}
		else
		{
			MessageBox::Show("Order detail does not exist");
		}
		connection->Close();
	}
	catch (Exception ^ e)
	{
		MessageBox::Show(e->Message);
	}

	txtSearch->Text = ("");
}
private: System::Void btnDelete_Click(System::Object^  sender, System::EventArgs^  e) {
	SQLinkedList s1;

	for (int i = 0; i < Order_Info->Rows->Count - 1; i++)
	{
		s1.push(Order_Info->Rows[i]->Cells["Order_ID"]->Value->ToString());
	}
	String^ theprevioustop = s1.getTop();
	s1.pop();
	Order_Info->Rows->Clear();

	SqlConnection^ connection = gcnew SqlConnection("Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true");

	try {
		connection->Open();


		SqlCommand^ cmd = gcnew SqlCommand("DELETE FROM [dbo].[Order_Detail] WHERE OrderID ='" + theprevioustop + "'", connection);
		cmd->ExecuteNonQuery();
		MessageBox::Show("Successfully Deleted");

		SqlCommand^ command = gcnew SqlCommand("SELECT * FROM  [dbo].[Order_Detail]", connection);

		SqlDataReader^ reader2 = command->ExecuteReader();
		while (reader2->Read())
		{
			Order_Info->Rows->Add(reader2[0]->ToString(), reader2[1]->ToString(), reader2[2]->ToString(), reader2[3]->ToString(), reader2[4]->ToString(), reader2[5]->ToString(), reader2[6]->ToString());
		}
		reader2->Close();

	}
	catch (SqlException^ e) {
		MessageBox::Show(e->Message);
	}

	finally{
		connection->Close();
	}
}

void Fillcomb2(void) {
			 String^ constring = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
			 SqlConnection^ conDataBase = gcnew SqlConnection(constring);
			 SqlCommand^ cmdDataBase = gcnew SqlCommand("SELECT *  FROM [dbo].[Company_Detail]", conDataBase);
			 SqlDataReader^ myReader;
			 try {
				 conDataBase->Open();
				 myReader = cmdDataBase->ExecuteReader();
				 while (myReader->Read()) {
					 String^ vName;
					 vName = myReader->GetString(0);
					 combCompanyname->Items->Add(vName);

				 }
			 }

			 catch (SqlException^ e) {
				 MessageBox::Show(e->Message);
			 }
			 finally{
				 conDataBase->Close();
			 }
		 }
private: System::Void Stock_Load(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void btnSave_Click(System::Object^  sender, System::EventArgs^  e) {

	try {
		SqlConnection^ connection = gcnew SqlConnection("Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true");
		connection->Open();
		String^ orderID = txtOrderid->Text;
		String^ Bookname = txtBookname->Text;
		String^ Authurname = txtAuthurname->Text;
		String^ Quantity = txtQuantity->Text;
		String^ Company_Name = combCompanyname->Text;
		String^ Order_Date = txtOrderdate->Text;
		String^ Status = combStatus->Text;

		SqlCommand^ query = gcnew SqlCommand();
		query->Connection = connection;
		query->CommandText = "UPDATE [dbo].[Order_Detail] SET Book_Name = '" + Bookname + "', [Aurthur_Name] = '" + Authurname + "', [Quantity] = '" + Quantity + "', [Company_Name] = '" + Company_Name + "', [Order_Date] = '" + Order_Date + "', [Status] = '" + Status + "' WHERE OrderID = '" + orderID + "'", connection;
		SqlDataReader^ reader = query->ExecuteReader();
		MessageBox::Show("Update Successful!");
		connection->Close();
		reader->Close();
	}
	catch (Exception^ e)
	{
		MessageBox::Show(e->Message);
	}

	// Textbox clear;
	txtOrderid->Text = ("");
	txtBookname->Text = ("");
	txtAuthurname->Text = ("");
	txtQuantity->Text = ("");
	txtOrderdate->Text = ("");
}
private: System::Void btnOrder_Click(System::Object^  sender, System::EventArgs^  e) {

	Order_Info->Rows->Clear();

	try
	{
		SqlConnection^ connection = gcnew SqlConnection();
		connection->ConnectionString = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
		connection->Open();

		SqlCommand^ query = gcnew SqlCommand();
		query->Connection = connection;
		String^ orderid = txtOrderid->Text;
		query->CommandText = "SELECT * FROM [dbo].[Order_Detail] WHERE OrderID ='" + orderid + "'", connection;

		SqlDataReader^ reader = query->ExecuteReader();

		Boolean exist;

		while (reader->Read() == true)
		{
			String^ id = reader->GetString(0);
			if (orderid == id)

			{

				exist = true;
				txtBookname->Text = reader->GetString(1);
				txtAuthurname->Text = reader->GetString(2);
				txtQuantity->Text = reader->GetString(3);
				combCompanyname->Text = reader->GetString(4);
				txtOrderdate->Text = reader->GetString(5);
				combStatus->Text = reader->GetString(6);
				

			}
			else
			{
				exist = false;
			}
		}
		reader->Close();
		if (exist == true)
		{
			return;
		}
		else
		{
			MessageBox::Show("Name does not exist in the database");
		}
		connection->Close();
	}
	catch (Exception ^ e)
	{
		MessageBox::Show(e->Message);
	}
}
};
}
