
#include "Stack_Queue.h"


namespace LibraryManagementSystem {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	//using namespace System::Data::Sql;
	using namespace System::Data::SqlClient;
	//using namespace System::Data::SqlTypes;
	

	/// <summary>
	/// Summary for Student
	/// </summary>
	public ref class Student : public System::Windows::Forms::Form
	{
	public:
		Form ^frm6;
		Student(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

		Student(Form ^frm1)
		{
			frm6 = frm1;
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}
	private: System::Windows::Forms::Button^  btnName;
	private: System::Windows::Forms::Button^  button1;
	public:

	public:

	public:


	internal: SQLinkedList s11;

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Student()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtSemester;
	private: System::Windows::Forms::TextBox^  txtTPnumber;
	private: System::Windows::Forms::TextBox^  txtName;
	protected:

	protected:


	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label2;



	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  txtIntakeCode;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Button^  btnUpdate;

	private: System::Windows::Forms::Button^  btnDelete;
	private: System::Windows::Forms::Button^  btnAdd;
	private: System::Windows::Forms::Button^  btnLoad;


	private: System::Windows::Forms::Button^  btnBack;
	private: System::Windows::Forms::TextBox^  txtSearch;

	private: System::Windows::Forms::Button^  button3;

	private: System::Windows::Forms::DataGridView^  Student_Information;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Student_Name;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  TP_Number;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Semester;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Intake_Code;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Student::typeid));
			this->txtSemester = (gcnew System::Windows::Forms::TextBox());
			this->txtTPnumber = (gcnew System::Windows::Forms::TextBox());
			this->txtName = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txtIntakeCode = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->btnUpdate = (gcnew System::Windows::Forms::Button());
			this->btnDelete = (gcnew System::Windows::Forms::Button());
			this->btnAdd = (gcnew System::Windows::Forms::Button());
			this->btnLoad = (gcnew System::Windows::Forms::Button());
			this->btnBack = (gcnew System::Windows::Forms::Button());
			this->txtSearch = (gcnew System::Windows::Forms::TextBox());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->Student_Information = (gcnew System::Windows::Forms::DataGridView());
			this->Student_Name = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->TP_Number = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Semester = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Intake_Code = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnName = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Student_Information))->BeginInit();
			this->SuspendLayout();
			// 
			// txtSemester
			// 
			this->txtSemester->Location = System::Drawing::Point(131, 150);
			this->txtSemester->Name = L"txtSemester";
			this->txtSemester->Size = System::Drawing::Size(192, 20);
			this->txtSemester->TabIndex = 12;
			// 
			// txtTPnumber
			// 
			this->txtTPnumber->Location = System::Drawing::Point(131, 113);
			this->txtTPnumber->Name = L"txtTPnumber";
			this->txtTPnumber->Size = System::Drawing::Size(192, 20);
			this->txtTPnumber->TabIndex = 11;
			// 
			// txtName
			// 
			this->txtName->Location = System::Drawing::Point(131, 78);
			this->txtName->Name = L"txtName";
			this->txtName->Size = System::Drawing::Size(192, 20);
			this->txtName->TabIndex = 10;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::Transparent;
			this->label3->Font = (gcnew System::Drawing::Font(L"Times New Roman", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label3->Location = System::Drawing::Point(30, 150);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(95, 22);
			this->label3->TabIndex = 9;
			this->label3->Text = L"Semester :";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::Transparent;
			this->label2->Font = (gcnew System::Drawing::Font(L"Times New Roman", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label2->Location = System::Drawing::Point(9, 113);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(115, 22);
			this->label2->TabIndex = 8;
			this->label2->Text = L"TP Number :";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->BackColor = System::Drawing::Color::Transparent;
			this->label4->Font = (gcnew System::Drawing::Font(L"Times New Roman", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label4->Location = System::Drawing::Point(9, 184);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(116, 22);
			this->label4->TabIndex = 14;
			this->label4->Text = L"Intake Code:";
			// 
			// txtIntakeCode
			// 
			this->txtIntakeCode->Location = System::Drawing::Point(131, 187);
			this->txtIntakeCode->Name = L"txtIntakeCode";
			this->txtIntakeCode->Size = System::Drawing::Size(192, 20);
			this->txtIntakeCode->TabIndex = 15;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->BackColor = System::Drawing::Color::Transparent;
			this->label5->Font = (gcnew System::Drawing::Font(L"Times New Roman", 21.75F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label5->Location = System::Drawing::Point(47, 22);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(262, 33);
			this->label5->TabIndex = 16;
			this->label5->Text = L"Student Information";
			// 
			// btnUpdate
			// 
			this->btnUpdate->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnUpdate.Image")));
			this->btnUpdate->Location = System::Drawing::Point(228, 254);
			this->btnUpdate->Name = L"btnUpdate";
			this->btnUpdate->Size = System::Drawing::Size(69, 54);
			this->btnUpdate->TabIndex = 19;
			this->btnUpdate->UseVisualStyleBackColor = true;
			this->btnUpdate->Click += gcnew System::EventHandler(this, &Student::btnSave_Click);
			// 
			// btnDelete
			// 
			this->btnDelete->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnDelete.Image")));
			this->btnDelete->Location = System::Drawing::Point(131, 254);
			this->btnDelete->Name = L"btnDelete";
			this->btnDelete->Size = System::Drawing::Size(69, 54);
			this->btnDelete->TabIndex = 18;
			this->btnDelete->UseVisualStyleBackColor = true;
			this->btnDelete->Click += gcnew System::EventHandler(this, &Student::btnDelete_Click);
			// 
			// btnAdd
			// 
			this->btnAdd->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnAdd.Image")));
			this->btnAdd->Location = System::Drawing::Point(39, 254);
			this->btnAdd->Name = L"btnAdd";
			this->btnAdd->Size = System::Drawing::Size(63, 54);
			this->btnAdd->TabIndex = 17;
			this->btnAdd->UseVisualStyleBackColor = true;
			this->btnAdd->Click += gcnew System::EventHandler(this, &Student::btnAdd_Click);
			// 
			// btnLoad
			// 
			this->btnLoad->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnLoad.Image")));
			this->btnLoad->Location = System::Drawing::Point(596, 383);
			this->btnLoad->Name = L"btnLoad";
			this->btnLoad->Size = System::Drawing::Size(69, 54);
			this->btnLoad->TabIndex = 20;
			this->btnLoad->UseVisualStyleBackColor = true;
			this->btnLoad->Click += gcnew System::EventHandler(this, &Student::button1_Click);
			// 
			// btnBack
			// 
			this->btnBack->Font = (gcnew System::Drawing::Font(L"Times New Roman", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnBack->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->btnBack->Location = System::Drawing::Point(775, 438);
			this->btnBack->Name = L"btnBack";
			this->btnBack->Size = System::Drawing::Size(93, 35);
			this->btnBack->TabIndex = 21;
			this->btnBack->Text = L"Back";
			this->btnBack->UseVisualStyleBackColor = true;
			this->btnBack->Click += gcnew System::EventHandler(this, &Student::btnBack_Click);
			// 
			// txtSearch
			// 
			this->txtSearch->Location = System::Drawing::Point(475, 34);
			this->txtSearch->Name = L"txtSearch";
			this->txtSearch->Size = System::Drawing::Size(368, 20);
			this->txtSearch->TabIndex = 26;
			// 
			// button3
			// 
			this->button3->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button3.Image")));
			this->button3->Location = System::Drawing::Point(409, 30);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(46, 33);
			this->button3->TabIndex = 25;
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Student::button3_Click);
			// 
			// Student_Information
			// 
			this->Student_Information->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Student_Information->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(4) {
				this->Student_Name,
					this->TP_Number, this->Semester, this->Intake_Code
			});
			this->Student_Information->Location = System::Drawing::Point(409, 78);
			this->Student_Information->Name = L"Student_Information";
			this->Student_Information->Size = System::Drawing::Size(434, 289);
			this->Student_Information->TabIndex = 27;
			this->Student_Information->CellClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Student::Student_Information_CellClick);
			this->Student_Information->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Student::Student_Information_CellContentClick);
			// 
			// Student_Name
			// 
			this->Student_Name->HeaderText = L"Student_Name";
			this->Student_Name->Name = L"Student_Name";
			// 
			// TP_Number
			// 
			this->TP_Number->HeaderText = L"TP Number";
			this->TP_Number->Name = L"TP_Number";
			// 
			// Semester
			// 
			this->Semester->HeaderText = L"Semester";
			this->Semester->Name = L"Semester";
			// 
			// Intake_Code
			// 
			this->Intake_Code->HeaderText = L"Intake_Code";
			this->Intake_Code->Name = L"Intake_Code";
			// 
			// btnName
			// 
			this->btnName->BackColor = System::Drawing::Color::Transparent;
			this->btnName->Font = (gcnew System::Drawing::Font(L"Times New Roman", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnName->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->btnName->Location = System::Drawing::Point(39, 72);
			this->btnName->Name = L"btnName";
			this->btnName->Size = System::Drawing::Size(86, 29);
			this->btnName->TabIndex = 28;
			this->btnName->Text = L"Name :";
			this->btnName->UseVisualStyleBackColor = false;
			this->btnName->Click += gcnew System::EventHandler(this, &Student::btnName_Click);
			// 
			// button1
			// 
			this->button1->Font = (gcnew System::Drawing::Font(L"Times New Roman", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->Location = System::Drawing::Point(34, 334);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(112, 33);
			this->button1->TabIndex = 29;
			this->button1->Text = L"Delete All";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Student::button1_Click_1);
			// 
			// Student
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::LightGray;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(870, 477);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->btnName);
			this->Controls->Add(this->Student_Information);
			this->Controls->Add(this->txtSearch);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->btnBack);
			this->Controls->Add(this->btnLoad);
			this->Controls->Add(this->btnUpdate);
			this->Controls->Add(this->btnDelete);
			this->Controls->Add(this->btnAdd);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->txtIntakeCode);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->txtSemester);
			this->Controls->Add(this->txtTPnumber);
			this->Controls->Add(this->txtName);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Name = L"Student";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Student";
			this->Load += gcnew System::EventHandler(this, &Student::Student_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Student_Information))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}

#pragma endregion
	private: System::Void btnBack_Click(System::Object^  sender, System::EventArgs^  e) {
		this->Hide();
		frm6->Show();
	}

private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {

	Student_Information->Rows->Clear();
	SqlConnection^ connection = gcnew SqlConnection("Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true");
	
	SQLinkedList s1;
	SqlCommand^ command = gcnew SqlCommand("SELECT * FROM [dbo].[Student_Information]", connection);
	
	try {
		connection->Open();
		SqlDataReader^ reader2 = command->ExecuteReader();
		
		while (reader2->Read())
		{

			Student_Information->Rows->Add(reader2[0]->ToString(), reader2[1]->ToString(), reader2[2]->ToString(), reader2[3]->ToString());
		
			s1.push(reader2["TP_Number"]->ToString());
		}
		reader2->Close();


	}
	catch (SqlException^ e) {
		MessageBox::Show(e->Message);
	}
	finally{
		connection->Close();
	}

	

}
private: System::Void Student_Information_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
	
}
private: System::Void Student_Load(System::Object^  sender, System::EventArgs^  e) {

	
	
}
private: System::Void btnAdd_Click(System::Object^  sender, System::EventArgs^  e) {
	String^ constring = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
	SqlConnection^ conDataBase = gcnew SqlConnection(constring);
	SqlCommand^ cmdDataBase = gcnew SqlCommand("INSERT INTO [dbo].[Student_Information]([Student_Name], [TP_Number], [Semester], [Intake_Code])VALUES ('" + this->txtName->Text + "' ,'" + this->txtTPnumber->Text + "' ,'" + this->txtSemester->Text + "' , '" + this->txtIntakeCode->Text +  "');", conDataBase);


	SqlDataReader^ myReader();
	try {
		conDataBase->Open();


		SqlDataReader^ myReader = cmdDataBase->ExecuteReader();
		while (myReader->Read()) {


		}

		MessageBox::Show("New Information");
	}
	catch (Exception^ ex) {
		MessageBox::Show(ex->Message);
	}

	//Text box clear;
	txtName->Text=("");
	txtTPnumber->Text=("");
	txtSemester->Text = ("");
	txtIntakeCode->Text = ("");


}
private: System::Void btnDelete_Click(System::Object^  sender, System::EventArgs^  e) {
	SQLinkedList s1; // object

	for (int i = 0; i < Student_Information->Rows->Count - 1; i++)
	{
		s1.push(Student_Information->Rows[i]->Cells["Student_Name"]->Value->ToString());
	}
	String^ theprevioustop = s1.getTop(); //get the data that comes first
	s1.pop();  //delete the data that recently added
	Student_Information->Rows->Clear();

	//Sql connection
	SqlConnection^ connection = gcnew SqlConnection("Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true");

	try {
		connection->Open();

		//delete from database
		SqlCommand^ cmd = gcnew SqlCommand("DELETE FROM [dbo].[Student_Information] WHERE Student_Name ='" + theprevioustop + "'", connection);
		cmd->ExecuteNonQuery();
		MessageBox::Show("Successfully Deleted");

		SqlCommand^ command = gcnew SqlCommand("SELECT * FROM  [dbo].[Student_Information]", connection);

		SqlDataReader^ reader2 = command->ExecuteReader();
		while (reader2->Read())
		{
			Student_Information->Rows->Add(reader2[0]->ToString(), reader2[1]->ToString(), reader2[2]->ToString(), reader2[3]->ToString());
		}
		reader2->Close();

	}
	catch (SqlException^ e) {
		MessageBox::Show(e->Message);
	}

	finally{
		connection->Close();
	}
}
private: System::Void btnSave_Click(System::Object^  sender, System::EventArgs^  e) {


	try {
		SqlConnection^ connection = gcnew SqlConnection("Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true");
		connection->Open();
		String^ name = txtName->Text;
		String^ tpnumber = txtTPnumber->Text;
		String^ semester = txtSemester->Text;
		String^ intakecode = txtIntakeCode->Text;

		SqlCommand^ query = gcnew SqlCommand();
		query->Connection = connection;
		query->CommandText = "UPDATE [dbo].[Student_Information] SET TP_Number = '" + tpnumber + "', [Semester] = '" + semester + "', [Intake_Code] = '" + intakecode + "' WHERE Student_Name = '"+name+"'", connection;
		SqlDataReader^ reader = query->ExecuteReader();
		MessageBox::Show("Update Successful!");
		connection->Close();
		reader->Close();
	}
	catch (Exception^ e)
	{
		MessageBox::Show(e->Message);
	}

	//Text box clear;
	txtName->Text = ("");
	txtTPnumber->Text = ("");
	txtSemester->Text = ("");
	txtIntakeCode->Text = ("");

}
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
	Student_Information->Rows->Clear();

	try
	{
		SqlConnection^ connection = gcnew SqlConnection();
		connection->ConnectionString = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
		connection->Open();

		SqlCommand^ query = gcnew SqlCommand();
		query->Connection = connection;
		String^ tp = txtSearch->Text;
		query->CommandText = "SELECT * FROM [dbo].[Student_Information] WHERE Student_Name='" + tp + "'", connection;


		SqlDataReader^ reader = query->ExecuteReader();

		Boolean exist;

		while (reader->Read() == true)
		{
			String^ id = reader->GetString(0);
			if (tp == id)

			{
				exist = true;
				Student_Information->Rows->Add(tp, reader->GetString(1), reader->GetString(2), reader->GetString(3));
			}
			else
			{
				exist = false;
			}
		}
		reader->Close();
		if (exist == true)
		{
			return;
		}
		else
		{
			MessageBox::Show("TP does not exist");
		}
		connection->Close();
	}
	catch (Exception ^ e)
	{
		MessageBox::Show(e->Message);
	}

	txtSearch->Text = ("");

}
private: System::Void btnName_Click(System::Object^  sender, System::EventArgs^  e) {

	Student_Information->Rows->Clear();

	try
	{
		SqlConnection^ connection = gcnew SqlConnection();
		connection->ConnectionString = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
		connection->Open();

		SqlCommand^ query = gcnew SqlCommand();
		query->Connection = connection;
		String^ name = txtName->Text;
		query->CommandText = "SELECT * FROM [dbo].[Student_Information] WHERE Student_Name ='" + name + "'", connection;

		SqlDataReader^ reader = query->ExecuteReader();

		Boolean exist;

		while (reader->Read() == true)
		{
			String^ id = reader->GetString(0);
			if (name == id)

			{

				exist = true;
				txtTPnumber->Text = reader->GetString(1);
				txtSemester->Text = reader->GetString(2);
				txtIntakeCode->Text = reader->GetString(3);
				
			}
			else
			{
				exist = false;
			}
		}
		reader->Close();
		if (exist == true)
		{
			return;
		}
		else
		{
			MessageBox::Show("Name does not exist in the database");
		}
		connection->Close();
	}
	catch (Exception ^ e)
	{
		MessageBox::Show(e->Message);
	}
}
private: System::Void Student_Information_CellClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
	
}
private: System::Void button1_Click_1(System::Object^  sender, System::EventArgs^  e) {

	try
	{
		//Sql connection
		SqlConnection^ connection = gcnew SqlConnection();
		connection->ConnectionString = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
		connection->Open(); //connection open

		//Delete all data from the database table
		SqlCommand^ query = gcnew SqlCommand("Delete From Student_Information", connection);
		query->ExecuteNonQuery();
		connection->Close(); //connection close
		MessageBox::Show("Deleted all data successfully");


	}
	catch (Exception ^ e)
	{
		MessageBox::Show(e->Message);
	}

}
};
}
