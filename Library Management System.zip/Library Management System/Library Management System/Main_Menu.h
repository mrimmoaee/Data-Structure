#pragma once
#include "Book.h"
#include "Student.h"
#include "Stock.h"
#include "Supplier.h"


namespace LibraryManagementSystem {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	//using namespace System::Data::SqlClient;

	/// <summary>
	/// Summary for Main_Menu
	/// </summary>
	public ref class Main_Menu : public System::Windows::Forms::Form
	{
	public:
		Form ^obj;
		Main_Menu(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}
		Main_Menu(Form ^obj1)
		{
			obj = obj1;
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}
		
	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Main_Menu()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected:
	private: System::Windows::Forms::Button^  btnBook;
	private: System::Windows::Forms::Button^  btnLogout;
	private: System::Windows::Forms::Button^  btnStudent;
	private: System::Windows::Forms::Button^  btnSupplier;
	private: System::Windows::Forms::Button^  btnOrder;


	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Main_Menu::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->btnBook = (gcnew System::Windows::Forms::Button());
			this->btnLogout = (gcnew System::Windows::Forms::Button());
			this->btnStudent = (gcnew System::Windows::Forms::Button());
			this->btnSupplier = (gcnew System::Windows::Forms::Button());
			this->btnOrder = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::WhiteSmoke;
			this->label1->Font = (gcnew System::Drawing::Font(L"Monotype Corsiva", 26.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->label1->Location = System::Drawing::Point(118, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(400, 43);
			this->label1->TabIndex = 5;
			this->label1->Text = L"Library Management System";
			// 
			// btnBook
			// 
			this->btnBook->BackColor = System::Drawing::Color::Silver;
			this->btnBook->Font = (gcnew System::Drawing::Font(L"Times New Roman", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnBook->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnBook.Image")));
			this->btnBook->ImageAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->btnBook->Location = System::Drawing::Point(117, 190);
			this->btnBook->Name = L"btnBook";
			this->btnBook->Size = System::Drawing::Size(190, 89);
			this->btnBook->TabIndex = 6;
			this->btnBook->Text = L"                 Book                  (Queue)";
			this->btnBook->UseVisualStyleBackColor = false;
			this->btnBook->Click += gcnew System::EventHandler(this, &Main_Menu::btnBook_Click);
			// 
			// btnLogout
			// 
			this->btnLogout->BackColor = System::Drawing::Color::SlateGray;
			this->btnLogout->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnLogout->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnLogout.Image")));
			this->btnLogout->Location = System::Drawing::Point(601, 12);
			this->btnLogout->Name = L"btnLogout";
			this->btnLogout->Size = System::Drawing::Size(64, 32);
			this->btnLogout->TabIndex = 7;
			this->btnLogout->UseVisualStyleBackColor = false;
			this->btnLogout->Click += gcnew System::EventHandler(this, &Main_Menu::btnLogout_Click);
			// 
			// btnStudent
			// 
			this->btnStudent->BackColor = System::Drawing::Color::Silver;
			this->btnStudent->Font = (gcnew System::Drawing::Font(L"Times New Roman", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnStudent->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnStudent.Image")));
			this->btnStudent->ImageAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->btnStudent->Location = System::Drawing::Point(117, 85);
			this->btnStudent->Name = L"btnStudent";
			this->btnStudent->Size = System::Drawing::Size(190, 89);
			this->btnStudent->TabIndex = 8;
			this->btnStudent->Text = L"            Student              (Stack)";
			this->btnStudent->UseVisualStyleBackColor = false;
			this->btnStudent->Click += gcnew System::EventHandler(this, &Main_Menu::btnStudent_Click);
			// 
			// btnSupplier
			// 
			this->btnSupplier->BackColor = System::Drawing::Color::Silver;
			this->btnSupplier->Font = (gcnew System::Drawing::Font(L"Times New Roman", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnSupplier->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnSupplier.Image")));
			this->btnSupplier->ImageAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->btnSupplier->Location = System::Drawing::Point(324, 190);
			this->btnSupplier->Name = L"btnSupplier";
			this->btnSupplier->Size = System::Drawing::Size(194, 89);
			this->btnSupplier->TabIndex = 9;
			this->btnSupplier->Text = L"             Supplier             (Queue)";
			this->btnSupplier->UseVisualStyleBackColor = false;
			this->btnSupplier->Click += gcnew System::EventHandler(this, &Main_Menu::btnSupplier_Click);
			// 
			// btnOrder
			// 
			this->btnOrder->BackColor = System::Drawing::Color::Silver;
			this->btnOrder->Font = (gcnew System::Drawing::Font(L"Times New Roman", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnOrder->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnOrder.Image")));
			this->btnOrder->ImageAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->btnOrder->Location = System::Drawing::Point(324, 85);
			this->btnOrder->Name = L"btnOrder";
			this->btnOrder->Size = System::Drawing::Size(194, 89);
			this->btnOrder->TabIndex = 10;
			this->btnOrder->Text = L"             Order Book             (Stack)";
			this->btnOrder->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->btnOrder->UseVisualStyleBackColor = false;
			this->btnOrder->Click += gcnew System::EventHandler(this, &Main_Menu::btnStock_Click);
			// 
			// Main_Menu
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::RoyalBlue;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(677, 307);
			this->Controls->Add(this->btnOrder);
			this->Controls->Add(this->btnSupplier);
			this->Controls->Add(this->btnStudent);
			this->Controls->Add(this->btnLogout);
			this->Controls->Add(this->btnBook);
			this->Controls->Add(this->label1);
			this->Name = L"Main_Menu";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Main_Menu";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnLogout_Click(System::Object^  sender, System::EventArgs^  e) {
		this->Hide();
		obj->Show();
	}
private: System::Void btnBook_Click(System::Object^  sender, System::EventArgs^  e) {
	this->Hide();
	Book ^frm2 = gcnew Book(this);
	frm2->ShowDialog();
}
private: System::Void btnStudent_Click(System::Object^  sender, System::EventArgs^  e) {
	this->Hide();
	Student ^frm1 = gcnew Student(this);
	frm1->ShowDialog();
}
private: System::Void btnStock_Click(System::Object^  sender, System::EventArgs^  e) {
	this->Hide();
	Stock ^frm3 = gcnew Stock(this);
	frm3->ShowDialog();
}
private: System::Void btnSupplier_Click(System::Object^  sender, System::EventArgs^  e) {
	this->Hide();
	Supplier ^frm4 = gcnew Supplier(this);
	frm4->ShowDialog();
}
};
}
