#pragma once
#include "Stack_Queue.h"


namespace LibraryManagementSystem {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Data::SqlClient;

	/// <summary>
	/// Summary for Supplier
	/// </summary>
	public ref class Supplier : public System::Windows::Forms::Form
	{
	public:
		Form ^frm7;
		Supplier(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}
		Supplier(Form ^frm4)
		{
			frm7 = frm4;
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Supplier()
		{
			if (components)
			{
				delete components;
			}
		}



	internal: SQLinkedList s11;
	private: System::Windows::Forms::Button^  btnBack;
	protected:
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  btnSave;
	private: System::Windows::Forms::Button^  btnDelete;
	private: System::Windows::Forms::Button^  btnAdd;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::TextBox^  txtBookname;

	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  txtPerson;



	private: System::Windows::Forms::TextBox^  txtCompanydetail;

	private: System::Windows::Forms::TextBox^  txtName;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label2;

	private: System::Windows::Forms::TextBox^  txtSearch;

	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::DataGridView^  Supplier_info;




	private: System::Windows::Forms::Button^  btnName;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Company_Name;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Company_Information;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Person_Contact;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Book_Name;









	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Supplier::typeid));
			this->btnBack = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->btnSave = (gcnew System::Windows::Forms::Button());
			this->btnDelete = (gcnew System::Windows::Forms::Button());
			this->btnAdd = (gcnew System::Windows::Forms::Button());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->txtBookname = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txtPerson = (gcnew System::Windows::Forms::TextBox());
			this->txtCompanydetail = (gcnew System::Windows::Forms::TextBox());
			this->txtName = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtSearch = (gcnew System::Windows::Forms::TextBox());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->Supplier_info = (gcnew System::Windows::Forms::DataGridView());
			this->Company_Name = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Company_Information = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Person_Contact = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Book_Name = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnName = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Supplier_info))->BeginInit();
			this->SuspendLayout();
			// 
			// btnBack
			// 
			this->btnBack->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnBack->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->btnBack->Location = System::Drawing::Point(845, 415);
			this->btnBack->Name = L"btnBack";
			this->btnBack->Size = System::Drawing::Size(82, 30);
			this->btnBack->TabIndex = 36;
			this->btnBack->Text = L"Back";
			this->btnBack->UseVisualStyleBackColor = true;
			this->btnBack->Click += gcnew System::EventHandler(this, &Supplier::btnBack_Click);
			// 
			// button1
			// 
			this->button1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button1.Image")));
			this->button1->Location = System::Drawing::Point(675, 338);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(69, 54);
			this->button1->TabIndex = 35;
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Supplier::button1_Click);
			// 
			// btnSave
			// 
			this->btnSave->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnSave.Image")));
			this->btnSave->Location = System::Drawing::Point(258, 249);
			this->btnSave->Name = L"btnSave";
			this->btnSave->Size = System::Drawing::Size(69, 54);
			this->btnSave->TabIndex = 34;
			this->btnSave->UseVisualStyleBackColor = true;
			this->btnSave->Click += gcnew System::EventHandler(this, &Supplier::btnSave_Click);
			// 
			// btnDelete
			// 
			this->btnDelete->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnDelete.Image")));
			this->btnDelete->Location = System::Drawing::Point(161, 249);
			this->btnDelete->Name = L"btnDelete";
			this->btnDelete->Size = System::Drawing::Size(69, 54);
			this->btnDelete->TabIndex = 33;
			this->btnDelete->UseVisualStyleBackColor = true;
			this->btnDelete->Click += gcnew System::EventHandler(this, &Supplier::btnDelete_Click);
			// 
			// btnAdd
			// 
			this->btnAdd->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnAdd.Image")));
			this->btnAdd->Location = System::Drawing::Point(69, 249);
			this->btnAdd->Name = L"btnAdd";
			this->btnAdd->Size = System::Drawing::Size(63, 54);
			this->btnAdd->TabIndex = 32;
			this->btnAdd->UseVisualStyleBackColor = true;
			this->btnAdd->Click += gcnew System::EventHandler(this, &Supplier::btnAdd_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->BackColor = System::Drawing::Color::Transparent;
			this->label5->Font = (gcnew System::Drawing::Font(L"Times New Roman", 18, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label5->Location = System::Drawing::Point(64, 15);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(232, 28);
			this->label5->TabIndex = 31;
			this->label5->Text = L"Company Information";
			this->label5->Click += gcnew System::EventHandler(this, &Supplier::label5_Click);
			// 
			// txtBookname
			// 
			this->txtBookname->Location = System::Drawing::Point(180, 182);
			this->txtBookname->Name = L"txtBookname";
			this->txtBookname->Size = System::Drawing::Size(192, 20);
			this->txtBookname->TabIndex = 30;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->BackColor = System::Drawing::Color::Transparent;
			this->label4->Font = (gcnew System::Drawing::Font(L"Times New Roman", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->label4->Location = System::Drawing::Point(37, 179);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(117, 22);
			this->label4->TabIndex = 29;
			this->label4->Text = L"Book Name :";
			// 
			// txtPerson
			// 
			this->txtPerson->Location = System::Drawing::Point(180, 145);
			this->txtPerson->Name = L"txtPerson";
			this->txtPerson->Size = System::Drawing::Size(192, 20);
			this->txtPerson->TabIndex = 27;
			// 
			// txtCompanydetail
			// 
			this->txtCompanydetail->Location = System::Drawing::Point(180, 108);
			this->txtCompanydetail->Name = L"txtCompanydetail";
			this->txtCompanydetail->Size = System::Drawing::Size(192, 20);
			this->txtCompanydetail->TabIndex = 26;
			// 
			// txtName
			// 
			this->txtName->Location = System::Drawing::Point(180, 73);
			this->txtName->Name = L"txtName";
			this->txtName->Size = System::Drawing::Size(192, 20);
			this->txtName->TabIndex = 25;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::Transparent;
			this->label3->Font = (gcnew System::Drawing::Font(L"Times New Roman", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->label3->Location = System::Drawing::Point(8, 145);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(147, 22);
			this->label3->TabIndex = 24;
			this->label3->Text = L"Person Contact :";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::Transparent;
			this->label2->Font = (gcnew System::Drawing::Font(L"Times New Roman", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->label2->Location = System::Drawing::Point(3, 108);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(152, 22);
			this->label2->TabIndex = 23;
			this->label2->Text = L"Company Detail :";
			// 
			// txtSearch
			// 
			this->txtSearch->Location = System::Drawing::Point(502, 19);
			this->txtSearch->Name = L"txtSearch";
			this->txtSearch->Size = System::Drawing::Size(418, 20);
			this->txtSearch->TabIndex = 38;
			// 
			// button3
			// 
			this->button3->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button3.Image")));
			this->button3->Location = System::Drawing::Point(436, 15);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(46, 33);
			this->button3->TabIndex = 37;
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Supplier::button3_Click);
			// 
			// Supplier_info
			// 
			this->Supplier_info->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Supplier_info->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(4) {
				this->Company_Name,
					this->Company_Information, this->Person_Contact, this->Book_Name
			});
			this->Supplier_info->Cursor = System::Windows::Forms::Cursors::Default;
			this->Supplier_info->Location = System::Drawing::Point(484, 62);
			this->Supplier_info->Name = L"Supplier_info";
			this->Supplier_info->Size = System::Drawing::Size(443, 270);
			this->Supplier_info->TabIndex = 39;
			// 
			// Company_Name
			// 
			this->Company_Name->HeaderText = L"Company_Name";
			this->Company_Name->Name = L"Company_Name";
			this->Company_Name->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::Programmatic;
			// 
			// Company_Information
			// 
			this->Company_Information->HeaderText = L"Company_Information";
			this->Company_Information->Name = L"Company_Information";
			// 
			// Person_Contact
			// 
			this->Person_Contact->HeaderText = L"Person_Contact";
			this->Person_Contact->Name = L"Person_Contact";
			// 
			// Book_Name
			// 
			this->Book_Name->HeaderText = L"Book_Name";
			this->Book_Name->Name = L"Book_Name";
			// 
			// btnName
			// 
			this->btnName->BackColor = System::Drawing::Color::Transparent;
			this->btnName->Font = (gcnew System::Drawing::Font(L"Times New Roman", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnName->Location = System::Drawing::Point(-5, 67);
			this->btnName->Name = L"btnName";
			this->btnName->Size = System::Drawing::Size(169, 29);
			this->btnName->TabIndex = 40;
			this->btnName->Text = L"Company Name :";
			this->btnName->UseVisualStyleBackColor = false;
			this->btnName->Click += gcnew System::EventHandler(this, &Supplier::btnName_Click);
			// 
			// Supplier
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::LightGray;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(949, 457);
			this->Controls->Add(this->btnName);
			this->Controls->Add(this->Supplier_info);
			this->Controls->Add(this->txtSearch);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->btnBack);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->btnSave);
			this->Controls->Add(this->btnDelete);
			this->Controls->Add(this->btnAdd);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->txtBookname);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->txtPerson);
			this->Controls->Add(this->txtCompanydetail);
			this->Controls->Add(this->txtName);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Name = L"Supplier";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Supplier";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Supplier_info))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnBack_Click(System::Object^  sender, System::EventArgs^  e) {
		this->Hide();
		frm7->Show();
	}
private: System::Void label5_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {

	Supplier_info->Rows->Clear();
	SqlConnection^ connection = gcnew SqlConnection("Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true");
	SQLinkedList s1;
	SqlCommand^ command = gcnew SqlCommand("SELECT * FROM [dbo].[Company_Detail]", connection);
	try {
		connection->Open();
		SqlDataReader^ reader = command->ExecuteReader();

		while (reader->Read())
		{
			s1.enqueue(reader["Company_Name"]->ToString());
		}
		reader->Close();

		for (int i = 0; i < s1.getSize(); i++)
		{
			String^ in = s1.inputData()->ToString();
			SqlCommand^ cmd = gcnew SqlCommand("SELECT * FROM [dbo].[Company_Detail] WHERE Company_Name ='" + in + "'", connection);
			SqlDataReader^ reader2 = cmd->ExecuteReader();
			while (reader2->Read())
			{
				Supplier_info->Rows->Add(in, reader2->GetString(1), reader2->GetString(2), reader2->GetString(3));
			}
			reader2->Close();
		}



	}
	catch (SqlException^ e) {
		MessageBox::Show(e->Message);
	}
	finally{
		connection->Close();
	}
	


}
private: System::Void btnAdd_Click(System::Object^  sender, System::EventArgs^  e) {
	SQLinkedList s1;

	String^ theprevioustop = s1.getBottom();

	String^ constring = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
	SqlConnection^ conDataBase = gcnew SqlConnection(constring);
	SqlCommand^ cmdDataBase = gcnew SqlCommand("INSERT INTO [dbo].[Company_Detail]([Company_Name], [Company_Information], [Person_Contact], [Book_Name])VALUES ('" + this->txtName->Text + "' ,'" + this->txtCompanydetail->Text + "' ,'" + this->txtPerson->Text + "' , '" + this->txtBookname->Text + "');", conDataBase);
	SqlCommand^ cmd = gcnew SqlCommand("INSERT INTO [dbo].[Company_Detail] WHERE [Company_Name] ='" + theprevioustop + "'", conDataBase);
	//INSERT INTO [dbo].[Company_Detail] WHERE [Company_Name]
	SqlDataReader^ myReader();
	try {
		conDataBase->Open();


		SqlDataReader^ myReader = cmdDataBase->ExecuteReader();
		while (myReader->Read()) {


		}

		MessageBox::Show("New Information Saved");
	}
	catch (Exception^ ex) {
		MessageBox::Show(ex->Message);
	}

	//Text box clear;
	txtName->Text = ("");
	txtCompanydetail->Text = ("");
	txtPerson->Text = ("");
	txtBookname->Text = ("");
}
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
	Supplier_info->Rows->Clear(); //clear table row

	try
	{
		//connect to database
		SqlConnection^ connection = gcnew SqlConnection();
		connection->ConnectionString = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
		connection->Open(); //connection open

		SqlCommand^ query = gcnew SqlCommand();
		query->Connection = connection;
		String^ tp = txtSearch->Text; //text box using for search

		//select from database table with the first name
		query->CommandText = "SELECT * FROM [dbo].[Company_Detail] WHERE Company_Name='" + tp + "'", connection;


		SqlDataReader^ reader = query->ExecuteReader();

		Boolean exist;

		while (reader->Read() == true)
		{
			String^ id = reader->GetString(0);
			if (tp == id) //match the name

			{
				exist = true;
				Supplier_info->Rows->Add(tp, reader->GetString(1), reader->GetString(2), reader->GetString(3));
			}
			else
			{
				exist = false;
			}
		}
		reader->Close();
		if (exist == true)
		{
			return;
		}
		else
		{
			MessageBox::Show("Company name does not exist");
		}
		connection->Close();
	}
	catch (Exception ^ e)
	{
		MessageBox::Show(e->Message);
	}
	//Text box clear;
	txtSearch->Text = ("");
}
private: System::Void btnDelete_Click(System::Object^  sender, System::EventArgs^  e) {
	SQLinkedList s1;

	for (int i = 0; i < Supplier_info->Rows->Count - 1; i++)
	{
		s1.enqueue(Supplier_info->Rows[i]->Cells["Company_Name"]->Value->ToString());
	}
	String^ thebottomtop = s1.getBottom();

	s1.dequeue();
	Supplier_info->Rows->Clear();

	SqlConnection^ connection = gcnew SqlConnection("Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true");

	try {
		connection->Open();


		SqlCommand^ cmd = gcnew SqlCommand("DELETE FROM [dbo].[Company_Detail] WHERE Company_Name='" + thebottomtop + "'", connection);
		cmd->ExecuteNonQuery();
		MessageBox::Show("Successfully Deleted");

		SqlCommand^ command = gcnew SqlCommand("SELECT * FROM [dbo].[Company_Detail]", connection);

		SqlDataReader^ reader2 = command->ExecuteReader();
		while (reader2->Read())
		{
			Supplier_info->Rows->Add(reader2[0]->ToString(), reader2[1]->ToString(), reader2[2]->ToString(), reader2[3]->ToString());
		}
		reader2->Close();


	}
	catch (SqlException^ e) {
		MessageBox::Show(e->Message);
	}
	finally{
		connection->Close();
	}
}
private: System::Void btnName_Click(System::Object^  sender, System::EventArgs^  e) {
	Supplier_info->Rows->Clear();

	try
	{
		SqlConnection^ connection = gcnew SqlConnection();
		connection->ConnectionString = "Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true";
		connection->Open();

		SqlCommand^ query = gcnew SqlCommand();
		query->Connection = connection;
		String^ name = txtName->Text;
		query->CommandText = "SELECT * FROM [dbo].[Company_Detail] WHERE Company_Name ='" + name + "'", connection;

		SqlDataReader^ reader = query->ExecuteReader();

		Boolean exist;

		while (reader->Read() == true)
		{
			String^ id = reader->GetString(0);
			if (name == id)

			{

				exist = true;
				txtCompanydetail->Text = reader->GetString(1);
				txtPerson->Text = reader->GetString(2);
				txtBookname->Text = reader->GetString(3);

			}
			else
			{
				exist = false;
			}
		}
		reader->Close();
		if (exist == true)
		{
			return;
		}
		else
		{
			MessageBox::Show("Company Name does not exist in the database");
		}
		connection->Close();
	}
	catch (Exception ^ e)
	{
		MessageBox::Show(e->Message);
	}
}
private: System::Void btnSave_Click(System::Object^  sender, System::EventArgs^  e) {
	try {
		SqlConnection^ connection = gcnew SqlConnection("Data Source=.\\SQLEXPRESS;Database=LibraryManagement;Integrated Security=true");
		connection->Open();
		String^ name = txtName->Text;
		String^ companydetail = txtCompanydetail->Text;
		String^ person= txtPerson->Text;
		String^ bookname = txtBookname->Text;

		SqlCommand^ query = gcnew SqlCommand();
		query->Connection = connection;
		query->CommandText = "UPDATE [dbo].[Company_Detail] SET Company_Information = '" + companydetail + "', [Person_Contact] = '" + person + "', [Book_Name] = '" + bookname + "' WHERE  Company_Name = '" + name + "'", connection;
		SqlDataReader^ reader = query->ExecuteReader();
		MessageBox::Show("Update Successful!");
		connection->Close();
		reader->Close();
	}
	catch (Exception^ e)
	{
		MessageBox::Show(e->Message);
	}

	//Text box clear;
	txtName->Text = ("");
	txtCompanydetail->Text = ("");
	txtPerson->Text = ("");
	txtBookname->Text = ("");

}
};
}
