#pragma once
#include <String>

using namespace System;
using namespace System::Windows::Forms;

public ref class NodeType
{
public:
	String ^info;//to store information
	NodeType ^link;//reference to the next node

};
public ref class SQLinkedList
{
public:
	NodeType ^top;//pointer, to point to the top node
	NodeType ^bottom;//pointer, to point to the bottom node
	int size; // variable to keep the size of the stack

	SQLinkedList() //constructor for initial node initialization
	{
		this->size = 0;
		this->top = nullptr;
		this->bottom = nullptr;

	}

	~SQLinkedList() //destructor to destroy the list in memory
	{
		NodeType ^current = top;
		while (top != nullptr)
		{
			current = current->link;
			delete top;
			top = current;
		}
	}

	bool isEmpty() //to check if the stack is empty or not
	{
		if (top == nullptr)
			return true;
		else
			return false;
	}

	void push(String ^value) //method to insert the new node at the beginning
	{
		NodeType ^newNode = gcnew NodeType;
		newNode->info = value;
		newNode->link = top;
		top = newNode;
		size++;

	}

	void enqueue(String ^value) //methos to insert new node at the beginning of the list (for queue)
	{
		NodeType ^newNode = gcnew NodeType;
		newNode->info = value;
		newNode->link = nullptr;
		if (top == nullptr) //insert to an empty list
		{
			top = bottom = newNode;
		}
		else
		{
			bottom->link = newNode;
			bottom = newNode;
		}
		size++;
	}

	void pop()//method to delete the first node in the list
	{
		if (isEmpty())
		{
			MessageBox::Show("The list is empty!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
		else
		{
			NodeType ^toBeDeleted = top;
			top = top->link;
			delete toBeDeleted;
			size--;

			//MessageBox::Show("Deleted!");
		}
	}

	void dequeue() //method to delete the first in the list
	{
		if (isEmpty())
			MessageBox::Show("The list is empty!", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		else {
			NodeType ^ toBeDeleted = top;
			top = top->link;
			delete toBeDeleted;
			size--;
		}

	}

	void clear() //my declaration, to clear the info in stack
	{
		while (getSize() > 0)
		{
			pop();
		}
	}

	String ^getTop() //to get the top item in the stack
	{
		if (isEmpty())
			return nullptr;
		else
			return top->info;
	}

	String ^getBottom() //to get the bottom iteam in the stack
	{
		if (isEmpty())
			return nullptr;
		else
			return bottom->info;
	}

	String ^inputData() //method to input the data into the listbox
	{
		if (isEmpty())
			MessageBox::Show("The list is empty!", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		else
		{
			NodeType ^data = top;
			top = top->link;
			return data->info;
			//return top->info;
		}

	}

	int getSize()
	{
		return size;
	}
};