#include "Login.h"
#include "Main_Menu.h"

using namespace System;
using namespace System::Windows::Forms;
[STAThread]

int main(array<String^>^args) {
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	LibraryManagementSystem::Login form;
	Application::Run(%form);

}